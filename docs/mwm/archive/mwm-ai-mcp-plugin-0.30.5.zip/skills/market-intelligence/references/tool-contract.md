# Market intelligence tool contracts

## `search_market_apps`

The tool accepts a semantic query, up to five reference apps, exact filters,
numeric filters, and ordered ranking criteria.

## Semantic selection

| Field | Values and notes |
| --- | --- |
| `query` | Product market, audience, goal, workflow, or capability. Required unless `reference_apps` is present. |
| `reference_apps` | `{store_id, device_type}` objects; `device_type` is `ios` or `android`; maximum 5. |
| `excluded_apps` | Same shape; maximum 100. Reference apps are already excluded. |
| `retrieval_mode` | `focused`, `balanced` (default), or `exploratory`. |
| `minimum_relevance` | Optional cosine-similarity floor from 0 to 1. It is not a probability. |

## Exact filters

`device_types` accepts `ios` and `android`. `categories` and `publisher_names`
are exact, case-insensitive matches. `is_game` and `is_free` are booleans.
Release and update bounds use inclusive `YYYY-MM-DD` values in:
`first_released_after`, `first_released_before`, `updated_after`, and
`updated_before`.

`metric_country` accepts a two-letter ISO country code. It is empty or `WW` for
the worldwide projection supplied directly by ST; never reconstruct that value
by summing countries. `metric_window_days`
accepts `7`, `30`, `90`, `180`, or `360` and defaults to 30. The previous
period has the same duration and immediately precedes the current period.

## Numeric filters

Each `numeric_filters` entry contains `field`, `operator`, and numeric `value`.

- Fields: `downloads`, `previous_downloads`, `downloads_delta`,
  `downloads_growth`, `revenue`, `previous_revenue`, `revenue_delta`,
  `revenue_growth`, `average_rating`, `ratings`.
- Operators: `gt`, `gte`, `lt`, `lte`.

Filter values must be published range boundaries such as `10`, `25`, `50`,
`100`, or `250`; equality is intentionally unavailable. Exact commercial
metrics remain private. Results expose stable `lower_bound`, `upper_bound`, and
`label` ranges with `precision: bucketed_ranges_v1`.

Growth is unavailable when the previous period is zero; such rows cannot satisfy
a growth filter and sort after rows with a defined growth value.

## Ordering and output size

`order_by` accepts up to three entries, evaluated in order. Each entry has a
`field` and optional `direction` (`asc` or `desc`, default `desc`). Accepted
fields are every numeric field above plus `relevance`, `first_release_date`,
`last_version_date`, and `name`.

`max_results` accepts 1 to 2000 and defaults to 20. `detail_level` is `compact`,
`standard` (default), or `full`. Prefer `compact` for large result sets; the
number returned can be lower after semantic selection and filtering.

## Examples

Direct competitors:

```json
{
  "reference_apps": [{"store_id": "123456789", "device_type": "ios"}],
  "query": "the app's professional DJ mixing workflow",
  "retrieval_mode": "focused",
  "order_by": [{"field": "relevance", "direction": "desc"}],
  "max_results": 20,
  "detail_level": "full"
}
```

Growth inside a broad market:

```json
{
  "query": "mobile entertainment apps",
  "retrieval_mode": "exploratory",
  "metric_window_days": 90,
  "numeric_filters": [{"field": "downloads", "operator": "gte", "value": 10}],
  "order_by": [{"field": "downloads_growth", "direction": "desc"}],
  "max_results": 100,
  "detail_level": "compact"
}
```

## `analyze_market_keywords`

The tool accepts the dynamic app list produced by `search_market_apps`, one
country and one store device segment. It returns demand, difficulty, dynamic
coverage and visibility plus the input apps ranked for each keyword.

| Field | Values and notes |
| --- | --- |
| `apps` | `{store_id, device_type}` objects; maximum 100 distinct apps. Apps incompatible with the requested device are reported in `ignored_apps`. |
| `country_code` | Required two-letter store country code. |
| `device_code` | `ios-phone`, `ios-tablet`, `android-phone`, or `android-tablet`. |
| `keyword_query` | Optional case-insensitive substring filter. |
| `minimum_popularity` | Relative demand floor from 0 to 10. |
| `maximum_difficulty` | Difficulty ceiling from 0 to 100. |
| `only_with_difficulty` | Exclude keywords without a recent difficulty estimate. |
| `minimum_ranked_apps` | Minimum ranked apps from the supplied compatible list; default 1. |
| `maximum_best_rank`, `maximum_rank` | Rank bounds from 1 to 100; `maximum_rank` defaults to 100. |
| `minimum_coverage_percent` | Minimum percentage of supplied compatible apps that rank. |
| `minimum_visibility_percent` | Minimum estimated share of keyword clicks captured by supplied apps. |
| `minimum_app_traffic_contribution_percent` | Require at least one app to attribute this share of its estimated ASO traffic to the keyword. |
| `max_rankings_per_keyword` | Per-keyword app details from 1 to 50; default 20. |
| `max_results` | Keywords from 1 to 200; default 50. |

`order_by` accepts at most three entries using `opportunity`, `popularity`,
`difficulty`, `visibility`, `ranked_apps`, `coverage`, `best_rank`,
`average_rank`, `traffic_contribution`, or `keyword`. Direction is `asc` or
`desc`. The default is opportunity, visibility, then popularity descending.

`opportunity_score` is `popularity × 10 - difficulty`. Popularity is relative
demand rather than an absolute search volume. Visibility is recomputed on the
dynamic app list with the `rank_ctr_v1` curve and must not be described as total
market share. Each ranking includes current rank, J-1 rank when available,
change, app identity, and the keyword's estimated share of that app's ASO
traffic. Check `ranking_as_of`, `difficulty_as_of`, and `limitations`.

Example after selecting a language-learning market:

```json
{
  "apps": [
    {"store_id": "570060128", "device_type": "ios"},
    {"store_id": "123456789", "device_type": "ios"}
  ],
  "country_code": "JP",
  "device_code": "ios-phone",
  "minimum_ranked_apps": 2,
  "only_with_difficulty": true,
  "order_by": [
    {"field": "opportunity", "direction": "desc"},
    {"field": "visibility", "direction": "desc"}
  ],
  "max_results": 50
}
```

Add market re## `get_market_chart_history`

Read complete-day App Store or Google Play positions from the daily chart archive.
Required: `country` (two letters) and `chart` (`free`, `paid`, or `grossing`).
Set `device_code` to `iphone` (default), `ipad`, or `android`. For iOS, provide
`genre_id` (`36` for All Apps); for Android, provide `play_category` such as
`APPLICATION`, `GAME`, or `MUSIC_AND_AUDIO`. Google Play chart data has no
phone/tablet split. Optional: `days` (1–90, default 30) and `top_n`
(1–100, default 25). The output contains `days` with ordered store IDs and
ranks, `as_of`, plus `movers`, `entrants`, and `exits` between the first and
last returned day. Positive `change` means a better rank. Entry and exit are
relative to the `top_n` cutoff; there is no download estimate.

## `get_market_reviews_insights`

Read public App Store review themes for one to five distinct apps. Required:
`apps` as `{store_id, device_type}` entries with numeric iOS IDs and
`device_type: "ios"`. Optional: `country_code` (two letters), `days` (30 or 90;
default 90). The output includes per-app and combined review counts, the
leading AI topic labels with current and previous-period counts, and up to
three public 1–2 star review examples per app. The window ends yesterday UTC.
Topics are non-exclusive; shares use each app's or the combined review count
as denominator. The examples do not represent all reviews. No developer reply
data is returned and this tool cannot post replies.

## `get_market_competitor_ads`

Read observed Meta ads for one to twenty distinct iOS or Android apps. Required:
`apps` as `{store_id, device_type}` entries. Optional: `active_only`, `ad_type`
(`video` or `static`), and `limit` (1–30, default 20). The result includes ad
copy, titles, up to four signed media links, creation and delivery dates,
`observed_at`, and `has_next`. The source's ad coverage is partial and the
result contains no spend, conversions, or exact commercial app metrics.
Each ad also includes up to four typed `media` entries (`url`, `type`,
`variant`, and `poster_url` for videos when a preview image exists). The tool
opens them in a gallery when the host supports MCP Apps.

## `show_market_media`

Display 1–24 selected media entries in one grid. Each `items` entry has a
signed MWM CDN `url`, `type` (`image` or `video`), and optional `title`,
`caption`, `observed_at`, and video `poster_url`. Keep full URLs including their signatures; links
from the Meta service expire. The gallery can open an original link when an
embedded image or video fails to load. This tool only displays media and does
not fetch more ads.
