# Store listing tool contract

All four tools are read-only, idempotent and free. The three connected ones
require an authenticated MWM account and declare the `mcp:stores.publish`
scope, the same as `get_store_connections`.

## Shared shape: `screenshots[]`

Every screenshot, whatever the source, is `{ url, width?, height?,
device_preset?, slot? }`:

- `url` — durable, full-size. Usable as `screenshot_url`, `hero_screenshot_url`,
  in `screens`, in `assets` or as `style_reference` of the screenshot tools;
- `width` / `height` — pixels when the source exposes them (App Store page,
  App Store Connect). Absent on Google Play;
- `device_preset` — `iphone_67`, `ipad_129`, `android_phone`, `android_tablet`,
  or empty when no generation slot renders at that size;
- `slot` — the store's own group name: an App Store Connect
  `screenshotDisplayType` (`APP_IPHONE_67`, the primary iPhone slot), with
  `display_name` its App Store Connect name ("iPhone with Dynamic Island
  (Large Display)"), a Play `imageType`
  (`phoneScreenshots`), or the public page's device key (`iphone_d73`).

## `get_public_store_listing`

- `store` — `ios` or `android`. May be left empty when `store_id` is a URL or
  unambiguous (numeric → App Store, dotted → package name);
- `store_id` — numeric App Store ID, Android package name, or a full
  `apps.apple.com` / `play.google.com` URL. A URL's country (`/fr/`, `gl=FR`)
  is used unless `country` is given;
- `country` — two-letter storefront, default `US`;
- `language` — storefront language (`fr-FR`); defaults to the storefront's own;
- `include_aso_analysis` — also runs MWM's ASO analysis of the page (App Store
  only, slower). Result in `aso_analysis`, shape owned by the ASO service.

Returns `store`, `store_id`, `store_url`, `country`, `language`, `name`,
`subtitle` (App Store), `developer`, `bundle_id` (App Store), `category`,
`rating`, `rating_count`, `free`, `price`, `icon_url`, `feature_graphic_url`
(Google Play), `description`, `short_description` (Google Play), `whats_new`,
`version`, `release_date`, `last_updated`, `locales` (App Store),
`screenshots[]`, `limitations[]`.

Limits: live version only; no keywords; Google Play exposes neither screenshot
dimensions nor tablet sets, so every Play screenshot is reported as
`android_phone`.

## `get_app_store_listing`

- `store_id` — required, the numeric App Store ID (App Store Connect app ID);
- `locales` — optional App Store Connect locales (`en-US`, `fr-FR`); empty
  returns all.

Returns `store_id`, `version` (`id`, `version_string`, `state`, `platform`,
`created_date`, `editable`) or null when the app has no iOS version,
`localizations[]` each with `locale`, `app_info_localization_id`,
`version_localization_id`, `name`, `subtitle`, `description`, `keywords`,
`promotional_text`, `whats_new`, `marketing_url`, `support_url`,
`privacy_policy_url`, and `screenshot_sets[]` — `{ id, display_type,
device_preset?, screenshots[] }`. Plus `limitations[]`.

The version returned is the editable draft when one exists, else the version in
review, else the live one. `editable: false` means nothing can be pushed until
a new version is created in App Store Connect.

Fails with "App Store Connect is not connected: call get_store_connections" when
no valid key covers the user. Which key: the integration linked to that app in
one of the user's organizations, else the first valid key found.

## `get_play_store_listing`

- `package_name` — required;
- `languages` — optional listing languages to read in full; empty reads the
  app's default language only.

Returns `package_name`, `default_language`, `available_languages[]` (every
language of the listing, read or not), `listings[]` each with `language`, `title`,
`short_description`, `full_description`, `video_url`, `icon_url`,
`feature_graphic_url`, and `screenshot_sets[]` — `{ image_type,
device_preset?, screenshots[] }` for `phoneScreenshots`,
`sevenInchScreenshots`, `tenInchScreenshots`. Plus `limitations[]`.

Each language read costs several Play Console calls, so only the default
language is read unless `languages` names others. Languages listed in
`available_languages` but absent from `listings[]` were not read: their texts
and images are unknown, not missing — a `limitations[]` line says so. Pass them
in `languages` for a localization task or a given market.
`get_store_listing_status` still checks every language.

Reads the current Play Console edit. When the user has several publishing
integrations, each is tried until one has access to the package. Fails with
"Google Play is not connected: call get_store_connections" when none is valid.

## `get_store_listing_status`

- `store` — `ios` or `android`;
- `store_id` — numeric App Store ID or package name.

Returns `store`, `store_id`, on Apple `version`, `state`, `editable`, then
`ready` and `locales[]` — each `{ locale, has_name, has_subtitle,
has_short_description, has_description, has_keywords, has_whats_new, has_icon,
has_feature_graphic, screenshot_slots[] { slot, device_preset?, count },
missing[] }` — and the flat `issues[]` list, one line per missing item, as
`"<locale>: missing <what>"`.

What counts as blocking (`ready: false`):

- App Store: no iOS version; a locale without name or description; a locale
  with no screenshot in `APP_IPHONE_67` / `APP_IPHONE_65` (iPhone with
  Dynamic Island / Face ID, Large Display);
- Google Play: a language without title, short or full description; fewer than
  two phone screenshots; no icon; no feature graphic.

Subtitle and keywords are reported as missing with the note `optional, but
indexed for search`; they never flip `ready`.
