---
name: store-listing
description: Read an app's store listing with the MWM MCP tools get_store_listing (the App Store texts MWM keeps for every editor, with drafts and what App Review needs), get_public_store_listing, get_app_store_listing, get_play_store_listing and get_store_listing_status, then iterate on the existing screenshots and texts. Use whenever an app is already published and the user wants to audit, improve, redo or localize its App Store or Google Play listing, compare it with competitors, or check what a listing still lacks before a submission.
---

# Store listing

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

This skill covers the read side of the stores on the `mwm-ai`
MCP server, with four tools: `get_public_store_listing`,
`get_app_store_listing`, `get_play_store_listing` and
`get_store_listing_status`. They generate nothing and change nothing. Their job
is to hand the creative tools what already exists on the store — texts, URLs,
dimensions, device slot — so the work starts from the real listing instead of a
blank page.

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: a draft, something visible on the
  store, something that goes to App Review, something that costs generations.
  Say it as a fact of the work, in your own words, never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## When to use it

Reach for these tools before any creative work on an app that is already
published:

- the user wants better screenshots, a new subtitle, a stronger description,
  or a localized listing for an existing app;
- the user asks what is wrong with, or missing from, their listing;
- a submission is being prepared and you need to know which locale or slot is
  empty;
- the user names a competitor whose listing should serve as a reference.

Reading a listing is free and idempotent. Read first, generate second.

## Public page or connected account?

Two sources exist, and they do not say the same thing.

**`get_public_store_listing`** reads the store page anyone can open. No account,
no consent: it works on the user's app and on any competitor. Pass `store`
(`ios` or `android`) and `store_id` — a numeric App Store ID, a package name, or
a full `apps.apple.com` / `play.google.com` URL, which is the most reliable
thing to ask a user for. `country` selects the storefront (default `US`);
`language` the storefront language. It picks the best source on its own and
says which in `source`: the store's API when one of the user's connected keys
covers the app (`app_store_connect` / `play_console` — the version being
prepared when there is one), else MWM Intelligence's daily snapshot of the
**published** version (`mwm_intelligence`, `scraped_at` its date), else a live
scrape of the store page (`store_live`). Never the keywords; no rating in the snapshot; on Google
Play no feature graphic, no tablet set and no screenshot dimensions.

**`get_app_store_listing`** and **`get_play_store_listing`** read the listing as
App Store Connect or Play Console hold it, through the accounts the user
connected on the MWM AI web app. They return the **editable draft** when there
is one, the keywords, every locale, and the exact screenshot sets with their
store slot. This is the source of truth for the user's own app. Both take the
same identifier as the public tool (`store_id` for Apple, `package_name` for
Google) and an optional list of locales. On Google Play only the default
language is read unless you pass `languages`: the other languages, listed in
`available_languages`, are unread, not missing — never conclude a language has
no screenshots from them. Pass them for a localization task.

Rule: for the user's own app, prefer the connected tools. Fall back to the
public page only when the store is not connected and the user does not want to
connect it now. For a competitor, the public page is the only option.

**`get_store_listing`**, when the server offers it, is the App Store listing
MWM keeps for every editor — the user in MWM Console, other agents, you. Take
the user's App Store texts from it: for each field the live value, the value in
the version being prepared, any draft with its author and reason, its status
(draft, sending, in App Store Connect, in review, live…), its `need` before App
Review (`required`, `optional`, `n/a`), and `readiness` for the version as a
whole. It never calls Apple: the copy is kept fresh automatically; pass
`check: true` only when the user says they just changed the store. Mention a
draft someone else wrote before proposing a change to that field, and read
`get_store_listing_activity` to tell what changed and who did it. Screenshots
still come from `get_app_store_listing`. Changing the texts is covered by the
`store-publish` skill.

**Which version to iterate on.** When the user's own app has a version being
prepared and a published one, and the request does not say which, ask once:
"On part de la version en préparation ou de la version publiée ?" — the
version in preparation comes from the connected tools, the published one from
`get_public_store_listing` with `published_only: true`.

**An app still in development** is in none of these sources: it lives in the
user's local project. When you can read it (Claude Code, Codex), take its name,
descriptions, screenshots and icon from the code and its metadata (fastlane,
`Info.plist`, `strings.xml`, asset folders) before any store call. When nothing
holds them, ask the user for the screenshots or the description rather than
guessing.

## Connection comes first

The connected tools fail with a clear message when the store is not connected.
When that happens, or when you are unsure, call `get_store_connections` first:
on hosts that render panels it opens the connection panel where the user drops
the key, elsewhere it returns the setup link to Settings → Integrations on the
MWM AI web app. Wait for the user to finish, call `get_store_connections` again
to confirm, then call the listing tool. The `store-connection` skill covers it.

**Never ask for a key, a `.p8` or a service-account JSON in the conversation.**
Keys go through the connection panel or the web app only; the tools never show
one, and nothing you can do in the chat can accept one.

## What the result gives you

Every screenshot comes back with a `url`, when known its `width` and `height`,
the store's own `slot` name, and a `device_preset`:

| `device_preset` | Store | Rendered at |
| --- | --- | --- |
| `iphone_67` | App Store — iPhone with Dynamic Island (Large Display): slots `APP_IPHONE_67`, `APP_IPHONE_65` | 1290×2796 |
| `ipad_129` | App Store — iPad 13-inch Display: slot `APP_IPAD_PRO_3GEN_129` | 2048×2732 |
| `android_phone` | Google Play (`phoneScreenshots`) | 1080×1920 |
| `android_tablet` | Google Play (7" and 10" sets) | 1600×2560 |

Name the App Store slots as App Store Connect shows them today, never by the
inch sizes the API enums carry (`APP_IPHONE_67` is not "6.7-inch"): the
listing returns a `display_name` per slot.

| API value | App Store Connect name |
| --- | --- |
| `APP_IPHONE_67` (`iphone_67`) | iPhone with Dynamic Island (Large Display) — 1320×2868, 1290×2796, 1260×2736 |
| `APP_IPHONE_65` | iPhone with Face ID (Large Display) — 1284×2778, 1242×2688 |
| `APP_IPHONE_61` | iPhone with Dynamic Island (Medium Display) — 1206×2622, 1179×2556 |
| `APP_IPHONE_58` | iPhone with Face ID (Medium Display) |
| `APP_IPHONE_55` / `APP_IPHONE_47` | iPhone with Home Button (Large / Medium Display) |
| `APP_IPAD_PRO_3GEN_129` (`ipad_129`) | iPad 13-inch Display — 2064×2752, 2048×2732 |
| `APP_IPAD_PRO_3GEN_11` | iPad 11-inch Display |

App Store Connect also has an **iPhone Duo** slot (2853×2007, 2034×1398) that
the screenshot API does not expose yet.

An empty `device_preset` means the screenshot sits in a slot the generation
tools do not render (a 6.1" iPhone set, a watch set, an iMessage set). Say so
rather than forcing a slot: a screenshot uploaded at the wrong size is rejected
by the store.

The texts come per locale: `name`, `subtitle`, `description`, `keywords`,
`promotional_text`, `whats_new` on the App Store; `title`, `short_description`,
`full_description` on Google Play, plus `icon_url` and `feature_graphic_url`.
The App Store result also carries `version` with its `state` and whether it is
`editable`. `limitations` names what the source could not tell — read it before
claiming something is absent.

## Iterating on existing screenshots

This is the flow the tools exist for. Once the listing is read:

1. Present the current series in one line per slot — how many screenshots,
   which `device_preset` — and ask what the user wants to change. Never
   re-embed the images as markdown; a plain link per screenshot is enough.
   To let the user see and drive the retouch, call `open_screenshot_studio`
   with the series in `screenshots` and its `device_preset`: the studio opens
   on those images, no upload step. Pass each screenshot's `thumbnail_url` too
   when the listing returned one: the grid then loads light renditions instead
   of six full-size images.
2. To apply one change to the whole series (a theme, a colour, a season), call
   `iterate_store_screenshots` **once** with all the URLs, the `change_prompt`
   and the `device_preset`. Never loop `iterate_store_screenshot` over the
   series: that is six blocks and six waits for one idea.
   To retouch one screenshot, call `iterate_store_screenshot` with its `url` as
   `screenshot_url`, the requested change as `change_prompt`, and **the
   `device_preset` returned with it**, so the edit keeps the store's size.
   Pass the rest of the series as `series` so the result shows the whole set.
   On the App Store, pushing that retouch back only uploads the new image: the
   other screenshots go back as their listing URLs and stay as they are.
3. To redesign the series around the app's real screens, pass the existing
   screenshots as `screens` to `design_store_screenshots`, the first one as
   `hero_screenshot_url`. The tool reads the slot from their dimensions.
4. To reproduce a competitor's style on the user's screens, read the competitor
   with `get_public_store_listing` and pass one of its screenshot URLs as
   `style_reference` to `generate_store_screenshots`, or describe the style in
   the prompt. Never reuse the competitor's images themselves.
5. To localize, hand the finished series to `localize_store_screenshots`. The
   listing tells you which locales exist and which have no screenshots.

Every generation is billed. Read once, then generate only what the user asked
for. The `store-screenshots` skill covers the generation tools themselves, and
the `store-publish` skill covers pushing the result back to the store.

## Checking readiness

`get_store_listing_status` reads the connected listing and returns, per locale,
what is missing, with a flat `issues` list to relay and a `ready` flag. It
separates what the store **requires** — on Apple a name, keywords, a
description and a support URL in every locale, the privacy policy URL in the
primary language, the version's copyright, and iPhone screenshots in the large
iPhone slot (Dynamic Island, or Face ID on an older app); on Google a title,
both descriptions, two phone screenshots, an icon and a feature graphic — from
what merely weakens the listing, which it labels `optional, but indexed for
search` (the subtitle). Where `get_store_listing` exists, its `readiness` says
the same for the texts, drafts included, plus What's New in every language of
an update and the primary category (chosen in App Store Connect, never
written by MWM): an empty required field the user has already written is not
missing, only not sent yet.

Call it before proposing work, so the proposal targets what is actually
missing, and again after anything was pushed to the store. When it reports that
the App Store version is not editable, say that a new version must be created
in App Store Connect before any text or screenshot can change.

## Restituting

Lead with what the user asked: the state of the listing, or what is missing.
One line per locale, one per slot. Quote the texts when they matter to the
question (a subtitle, a keyword string); do not paste a full description unless
asked. Point to the URLs rather than listing them.

If the tools remain unavailable after connection recovery, report the error.
Never describe a
listing you have not read, and never invent screenshot dimensions or a
`device_preset`.

See `references/tool-contract.md` for the full parameter contract.

## Seeing the current screenshots, not just their URLs

`get_public_store_listing`, `get_app_store_listing` and `get_play_store_listing`
take `include_images: true`: a few of the current screenshots come back as
images, not only as URLs. Set it before proposing a retouch, a custom product
page or a new concept — the description names the features, the screenshots
show which ones are already staged and how, which is what a concept should
build on rather than guess.
