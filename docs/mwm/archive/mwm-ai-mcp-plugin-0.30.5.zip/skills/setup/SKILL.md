---
name: setup
description: Connect the MWM AI plugin to an MWM account and verify its MCP tools. Use after installation, when MWM AI tools are missing or unavailable, or when the user needs to authenticate or reconnect the plugin. Store account configuration uses store-connection once MCP access works.
---

# Connect MWM AI

Installing the ZIP adds the plugin and its skills. The MWM account connection
is a separate OAuth step; importing the ZIP may not open the sign-in window.
Signing in to MWM Console alone does not connect the plugin to that account.

Use the user's language and keep the guidance short. Continue their original
task once the connection works.

## Check access

If MWM tools can be discovered in this conversation, call
`get_store_text_rules` with `stores: ["apple_app_store"]`,
`locales: ["en-US"]`, and `fields: ["keywords"]`. This is a free read that
needs no store integration, app ID, generation or publication. Report MCP
access as working only after a successful response. It does not establish
that the user's store accounts are connected or that every capability is
authorized.

When that tool is missing, or the host reports an authentication failure,
guide the user through connection instead of ending with "tools unavailable".

## Codex desktop connection

1. Open Settings → MCP servers. Find the server supplied by MWM AI and select
   **Authenticate** when sign-in is required. Its endpoint is
   `https://mcp.mwm.ai/mcp`.
2. In the browser opened by Codex, sign in to the user's MWM account and
   complete the OAuth consent. Let the host create the authorization request;
   sending someone directly to the bare Console consent URL does not start it.
3. Return to Codex, use **Restart** in the MCP settings if needed, and start
   a new chat if the current one still has the old tool catalog. Check access
   again and resume the original task.

If the imported plugin's server is absent from that list, check that MWM AI is
installed and enabled in the Plugins directory. If its tools still cannot be
loaded, use the documented direct connection: Settings → MCP servers →
**Add server**, name `mwm-ai`, transport **Streamable HTTP**, URL
`https://mcp.mwm.ai/mcp`; save, restart, then select **Authenticate**. Add this
only when there is no working MWM server for that endpoint, to avoid duplicate
connections. The installed plugin still supplies the workflows.

On another host, use its MWM AI plugin connection/authentication control.
Do not guess an interface path or claim the host supports a connection tool
that is not available.

## Errors after connection

- Missing tools after a successful login: check the plugin/server is enabled
  and refresh the host's tool catalog. A new chat can load the new connection.
- Authentication or expired-token errors: use the host's reconnect or
  Authenticate control, then repeat the read check.
- Missing-scope errors: explain which capability was refused and reconnect
  with that permission if the user's task requires it. A missing store
  integration is handled by [store-connection](../store-connection/SKILL.md).
- Network or server errors: report the actual error; logging in again does
  not fix an unreachable endpoint.

If recovery still fails, ask for the host version and the non-secret error
shown in its MCP settings, then point to [MWM support](mailto:support@mwm.ai).
Do not request passwords, tokens, browser callback URLs, private keys or store
credential files in chat. Do not generate assets, connect stores or publish
anything merely to test the MCP connection.
