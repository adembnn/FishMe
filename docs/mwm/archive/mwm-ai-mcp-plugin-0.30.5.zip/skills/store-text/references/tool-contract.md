# Store text tool contract

Both tools are free, read-only and idempotent: they read a table compiled into
the server and count characters. Nothing is billed, nothing is written, and
calling again after a fix costs nothing — which is the point, since the loop is
write, lint, fix, lint.

**No limit appears in this file.** They live in the catalogue that
`get_store_text_rules` returns and that ships inside every `review_store_text`
result, so a limit that changes reaches you with the server rather than with a
plugin update.

## `get_store_text_rules`

Every field optional:

- `stores` — `apple_app_store`, `google_play`; both when omitted;
- `locales` — the locales you intend to ship. Each comes back with its
  canonical form per store, which is **not** strict BCP-47 and differs between
  the two stores;
- `fields` — restrict the answer to some field ids, e.g. `keywords`.

Returns `spec`: the closed vocabulary for variant angles
(`variant_strategies`, each with the label an interface shows), then per store
the field catalogue (id, label, min/max, requiredness,
indexation, mutability, storage column), the rule table (id, severity,
authority, whether it is contested, message, fix, source), and the locale
resolutions.

## `review_store_text`

### The sheets

`listings` — one entry per (store, locale), at most 20:

- `store` — `apple_app_store` or `google_play`;
- `locale` — your best guess; the canonical form comes back with the result;
- `apple` — `name`, `subtitle`, `keywords`, `promotional_text`, `description`,
  `whats_new`. Set this **or** `google_play`, never both;
- `google_play` — `title`, `short_description`, `full_description`,
  `release_notes`;
- `is_first_version` — true only for a first submission; otherwise the What's
  New field is treated as required;
- `live` — what the store shows today, keyed by that store's field ids. Drives
  the before/after column and the warning about replacing indexed characters;
- `variants` — alternative wordings, `{field, value, strategy, rationale}`, at
  most 12 per sheet. Not for a 4000-character description. `strategy` comes from
  the closed list in `spec.variant_strategies` — `keyword_oriented`,
  `product_oriented`, `benefit_oriented`, `brand_oriented`, `concise` — because
  it is the only label a reviewer reads before picking; anything else is shown
  as an unnamed alternative. `recommended` is reserved for the copy in the
  field, which is labelled that way on its own;
- `locked` — field ids the reviewer settled and asked you to reuse
  byte-identical. Changing one is reported as a blocker;
- `notes` — anything the reviewer must know about this locale.

A sheet whose store and field object disagree, or that sets both objects, is
**rejected rather than guessed**, and named in `rejected`.

### The context that makes the audit work

`app_name`, `publisher_name`, `brand_tokens`, `competitor_names`,
`primary_locale`, `market_country`, `brief`, `icon_url`, `captions`,
`target_keywords`, `evidence`, `include_rules`.

- `publisher_name` — Apple already indexes it, so keyword terms repeating it
  are reported as wasted budget;
- `brand_tokens` — words the app legitimately capitalises, so the ALL-CAPS and
  superlative checks stop flagging them;
- `competitor_names` — from `search_market_apps`; without it nothing can check
  the visible fields for a rival's name. Matching is on a whole name, never on a
  common word inside one, so a rival called "Metronome Beats" does not make
  "metronome" a forbidden word. The keyword field is deliberately not checked:
  it is not user-visible, and Apple's stated remedy there is to modify the
  keywords, not to refuse the listing;
- `market_country` — distinct from locale on purpose: `fr-FR` copy can target
  Canada, and every keyword source upstream is keyed by country;
- `target_keywords` — `{term, priority, source, popularity, has_difficulty,
  difficulty, country_code, device_code, as_of}`. `has_difficulty` is the
  presence flag: upstream, an unscored term reads as difficulty 0, which means
  *not scored*, never *easy*. Leave a metric out rather than estimating it;
- `include_rules` — echo the whole catalogue in the text result. Useful on the
  first call of a session, pointless afterwards.

### The result

- `verdict` — `blocked`, `warnings` or `clean`, plus the three counts;
- `sheets` — per sheet: the canonical locale, and **every field of the
  catalogue including the empty ones**, each with its value, its count, its
  limit and its findings. Empty fields are returned on purpose: a missing Play
  release note is the most frequent Android blocker, and hiding the row would
  hide the blocker;
- `release` — how many sheets are shippable and why the others are not;
- `spec` — the catalogue, so the interface can recount on every keystroke
  against the numbers the server used;
- `prefill`, `evidence`, `keywords` — echoed back verbatim;
- `rejected` — what was dropped, and why.

One value does come back changed, and only one: the Apple keyword field has its
separators normalized to `term,term`, with a note saying how many characters
that recovered. Syntax is normalized, words never are — every term comes back
exactly as written, in the order it was written.

### Findings

`{rule_id, severity, authority, contested, field, message, fix, fix_value,
excerpt, measure, actual, limit, source, computed_in}`.

`severity` says what happens if you ignore it — `blocker` means the store
refuses or truncates, or an MWM release gate refuses the push. `authority` says
who says so, and the two are independent:

| authority | meaning | what you do |
| --- | --- | --- |
| `store_enforced` | observed to be refused or truncated | fix it |
| `store_documented` | written by the store, enforcement unobserved | fix it |
| `mwm_pipeline` | MWM's own gate, sometimes stricter than the store | fix it, and say the store would have accepted |
| `vendor_consensus` | ASO tooling agrees, no store source | do not rewrite on your own initiative |
| `folklore` | widely repeated, unverifiable | counted, not unfolded |

`contested` marks a rule the store documents two ways; it is never a blocker.
`fix_value` is a ready replacement when the repair is purely mechanical.
`computed_in` says whether the server or the interface evaluated it — some
rules need a Unicode word segmenter the Go standard library does not have, so
for Japanese, Chinese, Korean and Thai the server declines them and says so
rather than answering badly.

### The text content

The first block is for you: the verdict, one line per finding grouped across
sheets, and — always — the instruction for hosts that render no interface. The
following blocks are addressed to the reader: the short fields in full with
their counts, so the proposal is legible even with no interface at all.

## No studio-only tool

Every rule in the table is evaluated identically by the server and by the
interface, from the same data, so the interface needs no round trip to re-lint
after a human edit. There is no hidden tool, and both tools are safe for you to
call again.
