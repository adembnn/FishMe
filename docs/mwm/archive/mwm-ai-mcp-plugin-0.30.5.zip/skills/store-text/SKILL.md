---
name: store-text
description: Write App Store and Google Play listing text — app name, subtitle, keywords, descriptions, release notes — and check it against the stores' real limits and policies with the MWM MCP tools get_store_text_rules and review_store_text. Use whenever store copy is being written or rewritten, when a submission is being prepared, when a listing is localized into a new language, when a second store is added, or when someone asks why an app is not being found.
---

# Store text (ASO copy)

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

You write the copy. The `mwm-ai` MCP server tells you what is
legal and hands your proposals to a human to compare, edit and pick.

Two tools:

- `get_store_text_rules` — the catalogue: every text field of both stores, its
  exact limit, whether it is indexed for search, when a change reaches the
  store, the machine-checkable rules, and the canonical locale codes;
- `review_store_text` — lints the sheets you wrote and opens the review
  interface for a human.

Neither generates text. There is no tool that writes store copy: that is your
job, and it is why the sections below are about writing, not about calling.

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: a draft, something visible on the
  store, something that goes to App Review, something that costs generations.
  Say it as a fact of the work, in your own words, never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## When to offer it

Offer without waiting to be asked when a submission is being prepared and the
listing is empty or stale, when the positioning changes, when a locale or a
second store is added, or when someone asks why the app is not being found.
Offer it **once**, in one sentence.

## Fetch the rules first, always

Call `get_store_text_rules` with the stores and locales you intend to ship,
before writing anything.

**This skill deliberately contains no numbers.** Limits, indexation and locale
forms are product constants that move, and the server is the only place where
they are current. A limit you remember is a limit that was true once. The
locale codes in particular cannot be guessed: App Store Connect wants a bare
`it`, `ja`, `ko` or `sv` and refuses `it-IT` or `ja-JP`, while Google Play
wants `ja-JP` and `zh-CN` — the two stores disagree, on purpose.

## Field ids belong to one store and are never shared

The two stores' field sets share no identifier, and that is not cosmetic: an
Apple `subtitle` and a Play `short_description` have different budgets, an
Apple `whats_new` and a Play `release_notes` have different budgets, and MWM's
own database collapses each pair into a single column. **Never carry a value
from one store's field to the other's.** Write each store's copy for that
store.

## Gather evidence, then measure demand

1. `search_market_apps` — `retrieval_mode: "focused"`, `detail_level: "full"`,
   `max_results` at 20 or below (a full detail level over 100 apps overflows
   the tool result). Read what competitors actually say.
2. `analyze_market_keywords` — pass the `store_id` / `device_type` pairs you
   just retrieved, plus the country and device you target. **This is where
   popularity and difficulty come from.** Never invent either.

Then pass what you used **verbatim** into `review_store_text`: the competitor
rows in `evidence`, the terms in `target_keywords` with their metrics. The
reviewer sees what your proposal was measured against instead of taking your
word for it.

Say what the corpus is not: a subtitle absent from market intelligence means
*not recorded on our side*, never *they have no subtitle*. Relevance is a
retrieval signal, not market share.

An app with no competitors supplied and no store presence has no keyword
metrics available — say so rather than estimating.

## Write per (store, locale), and send them all in one call

One `listings` entry per store and locale, all in a single `review_store_text`
call: they are reviewed side by side and the human decides once. Splitting them
across calls makes the same person decide the same thing twice.

## Variants only where the choice is real

Two or three alternatives on the fields where wording genuinely changes the
outcome — name, subtitle, title, short description, promotional text. **Never
on a 4000-character description**: it is noise in a comparison view and
kilobytes of payload per locale.

`strategy` is a **closed list**, not free text — it is the only thing a reviewer
reads before picking a wording, so it has to mean the same thing every time:

| `strategy` | the angle it takes |
| --- | --- |
| `keyword_oriented` | places the terms people search for, at the cost of the promise |
| `product_oriented` | says what the app is, plainly |
| `benefit_oriented` | leads with what the user gets |
| `brand_oriented` | leads with the name, for an audience that already knows it |
| `concise` | shorter than it needs to be, leaving room in the neighbouring fields |

Anything else shows up as an unnamed alternative, which wastes the one label the
reviewer gets. Do not use `recommended`: the copy you put in the field *is* the
recommendation, and it is labelled that way automatically. The full list, with
labels, is in `spec.variant_strategies`.

`rationale` is one sentence naming the evidence — what it targets, not that it
is good.

## Always write Play release notes, from the first draft

It is the one field nothing in the platform generates and that MWM's Android
release gate requires for every locale. Omitting it blocks the push weeks
later, on a listing everything upstream declared complete.

## Localize, do not translate

Apple's keyword field is not shared between localizations: each locale has its
own budget, so the target locale needs the terms its users actually type, which
may share nothing with the source. And translation expands — a subtitle that
fits in French often does not in German. Rewrite each field to the locale's
budget, then review.

Apple's description and keywords do **not** inherit from the primary language:
every locale you add needs its own explicitly.

## Fill the four fields that make the audit possible

`publisher_name`, `brand_tokens`, `competitor_names`, `market_country`.
Omitting them does not fail the call — it silently weakens the review. Without
`publisher_name` the wasted-keyword audit misses the seller name Apple already
indexes; without `competitor_names` nothing can check the **visible** fields for
a rival's name, which is what guideline 2.3.7 is about: a subtitle "should not
reference other apps". The keyword field is not checked for that — it is not
user-visible, and for it Apple states a different consequence, that it "may
modify inappropriate keywords at any time".

Two things you do not have to think about: the keyword separators, which are
cleaned for you, and any punctuation in that field. Write the terms.

## Reading the result

Summarize in **one line**: how many sheets, how many variants, how many
blockers. Then stop — the interface displays the copy.

Findings carry a severity **and** an authority, and the two are independent:

- `store_enforced` / `store_documented` — fix these. A `blocked` verdict means
  the store refuses, truncates, or an MWM release gate refuses the push: apply
  the fixes and call `review_store_text` again.
- `mwm_pipeline` — MWM's own gate, sometimes stricter than the store itself.
  Fix it, and say that the store would have accepted it.
- `vendor_consensus` / `folklore` — practitioner habit, not policy. Do **not**
  rewrite the copy for these on your own initiative. Mention them if the human
  asks.

Never say a listing is "compliant" because the verdict is `clean`: it means no
rule in the table fired, not that App Review agrees.

## The review sends you two kinds of message — read the first line

**A report** starts with "Here is the store text retained from the review" and
ends by telling you to call no tool. It carries the retained text in full, with each
field's provenance. **Call nothing.** Do not re-run `review_store_text` to
"double-check", do not call `search_market_apps` to "validate". Acknowledge in
one sentence and wait. This instruction matters more here than anywhere else:
you are the writer, so a report full of copy reads like an invitation to
improve it. It is not.

**A correction request** starts with "Fix this store text". It carries, in this
order, whatever applies: the blockers to fix, what the reviewer asks for in
their own words, and the fields already settled. Fix exactly what it names, put
the settled fields in `locked` as it asks, and call `review_store_text` once.
Do not widen the scope, do not rewrite what the human kept.

**A request can carry no blocker at all** — only the reviewer's sentence. A
sheet can pass every rule and still not be what they wanted, so "nothing is
blocking" is not an argument against the request. Do what it asks and nothing
more.

## What not to do

- Never paste the store copy back into your reply — the result already carries
  it, and the interface displays it.
- Never truncate a field to make it fit. Rewrite it shorter.
- Never invent a popularity, a difficulty, or a ranking prediction.
- Never guess a locale code; read the canonical form the tools return.
- Never treat one store's sheet as the other's translation.
- Never claim a listing has been saved or pushed: no tool on this server
  writes anything, anywhere.
- If the tools remain unavailable after connection recovery, report the error. Do not fall back on
  half-remembered limits — that is exactly how a rejected submission happens.

See [references/tool-contract.md](references/tool-contract.md) for the full
parameter contract.
