# Store release tool contract

All five tools require an authenticated MWM account and declare the
`mcp:stores.publish` scope, the same as `get_store_connections`: reading a
release and shipping a build are the same consent, and no store key is ever
returned to the agent. Four are read-only; `publish_build_to_play_track` is
destructive and not idempotent.

## `get_store_builds`

- `store` — `ios` or `android`. May be left empty when `store_id` is
  unambiguous (numeric → App Store, dotted → package name), and a store URL is
  accepted;
- `store_id` — numeric App Store ID, or Android package name;
- `limit` — how many builds, newest first. Default 20.

Returns `store`, `store_id`, `builds[]`, `highest_version_code` (Google Play
only) and `limitations[]`.

Each build is `{ id?, version?, version_code?, processing_state?,
distributable, uploaded_date?, expiration_date?, tracks[]? }`:

- `id` — the App Store Connect build id. Google Play has none: a build is named
  by its version code there;
- `version` — the build number on iOS (`CFBundleVersion`), the release name on
  Android;
- `processing_state` — Apple's own: `PROCESSING`, `VALID`, `INVALID`, `FAILED`.
  Absent on Google Play;
- `distributable` — the build can be sent to a tester or attached to a version
  right now. On iOS that means `VALID`; on Android, that Google already
  accepted the version code into a track;
- `tracks` — the Play tracks the version code sits in. Empty on iOS.

Limits: Google Play exposes no upload or processing history through this
integration, so the Android list is derived from the tracks — a bundle uploaded
and never assigned to a track does not appear. `highest_version_code` is the
number the next upload has to beat.

## `get_store_release_status`

- `store` — `ios` or `android`, same tolerance as above;
- `store_id` — numeric App Store ID, or Android package name.

Returns `store`, `store_id`, `stage`, and then one side or the other:

- App Store: `version` (`id`, `version_string`, `state`, `editable`) and
  `review` (`submission_id`, `state`) when a submission exists;
- Google Play: `tracks[]` — `{ track, name?, status, version_codes[],
  rollout_percent }` — plus `has_production_draft` and
  `highest_version_code`.

`stage` is derived from those fields, never from a second store call:

| `stage` | Means |
| --- | --- |
| `no_version` | nothing is being prepared |
| `editable` | the listing and the attached build can still be changed |
| `in_review` | Apple is reviewing; the listing cannot be edited |
| `pending_release` | approved, waiting for the developer to release |
| `rolling_out` | a Play production release is in progress or halted |
| `live` | the version is the one users get |
| `unknown` | a version state this server does not map yet |

`rollout_percent` is the share of users a staged Play release serves: 100 once
the release is `completed`.

Limits: Google Play has no review submission object — an edit is reviewed after
it is committed, and the outcome shows as the track release changing status. On
iOS, a failing review call is reported in `limitations` rather than failing the
read: the version state is the useful half.

## `prepare_build_upload`

- `store_id` — required, the Android package name the build belongs to;
- `filename` — required, and it must end in `.aab` or `.apk`;
- `size_bytes` — optional; refuses an impossible upload before it starts.

Returns `upload_id`, `upload_url`, `expires_at`, `format` and `instructions`.

The bytes go straight from the user to MWM storage: PUT the file to
`upload_url` with `Content-Type: application/octet-stream` and **no**
Authorization header. The content type is part of the signature, so it has to
be exactly that one. The slot lives 30 minutes and accepts one file of at most
1 GB.

The call fails before handing out a slot when Google Play is not connected or
the package is unreachable — deliberately, so nobody uploads 300 MB for
nothing.

## `get_build_upload`

- `upload_id` — required, as returned by `prepare_build_upload`.

Returns `upload_id`, `format`, `size_bytes`, `checksum_md5`, `uploaded_at` and
`ready`. `ready: false` means the slot exists but the PUT has not happened or
did not finish.

`checksum_md5` is computed by the storage layer when it receives the bytes, so
it describes what is stored, not what was announced. It is the value
`publish_build_to_play_track` demands back.

## `publish_build_to_play_track`

- `store_id` — required, the Android package name;
- `upload_id` — required;
- `confirm_checksum_md5` — required, and it must equal the `checksum_md5` the
  read-back returned. A mismatch refuses the publication before any network
  call;
- `track` — required: `internal`, `alpha`, `beta` or `production`;
- `version_name` — optional release name shown in Play Console;
- `release_notes` — optional, `en-US`;
- `status` — optional: `draft`, `inProgress`, `halted`, `completed`. Defaults
  to `completed` on a test track and `draft` on production.

Returns the receipt: `store`, `store_id`, `track`, `status`, `upload_id`,
`checksum_md5`, `size_bytes`, `version_code`, `edit_id`, `message?` and
`next_step`.

`version_code` is the one Google read from the bundle's manifest — the
authority, whatever anyone assumed. `message` appears when what Google found
differs from what was announced.

Irreversible: Google commits the edit, and the version code is consumed. A
retry with the same bundle fails on Google's side rather than publishing twice,
because a version code cannot be reused — but that is a consequence, not a
substitute for asking the user first.

iOS is not covered by this tool: an `.ipa` goes to TestFlight through
Transporter and the Apple signing chain, which this server does not do.
