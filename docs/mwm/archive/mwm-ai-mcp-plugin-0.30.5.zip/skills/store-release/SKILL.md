---
name: store-release
description: Ship a build with the MWM MCP tools get_store_builds, get_store_release_status, prepare_build_upload, get_build_upload and publish_build_to_play_track. Use whenever the user asks what builds exist, where their app stands between preparation and live, whether a version is in review or rolling out, or wants to send an Android bundle to an internal, alpha, beta or production track.
---

# Store release

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

Five tools on the `mwm-ai` MCP server cover the release side
of the user's own apps, through the accounts connected with
`get_store_connections`:

| Tool | Does |
| --- | --- |
| `get_store_builds` | the builds a store holds: iOS build numbers and processing state, Android version codes and their tracks |
| `get_store_release_status` | where the app stands: App Store version and review, Play tracks and rollout, plus one `stage` word |
| `prepare_build_upload` | opens a one-shot slot to upload an `.aab` or `.apk` |
| `get_build_upload` | says what actually landed in that slot: size and checksum |
| `publish_build_to_play_track` | sends that artifact to a Google Play track — irreversible |

The first two are reads. The last one is the only write, and Google commits the
edit on its side: a version code is consumed for good.

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: a draft, something visible on the
  store, something that goes to App Review, something that costs generations.
  Say it as a fact of the work, in your own words, never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## Read before anything else

`get_store_release_status` answers "where is my app" for both stores, and its
`stage` is one word you can branch on without parsing store vocabulary:

`no_version` · `editable` · `in_review` · `pending_release` · `rolling_out` ·
`live` · `unknown`

Two consequences worth acting on: an app `in_review` cannot have its listing
edited, so say that before offering to change texts or screenshots; and a
`rolling_out` app has a percentage of users served, which is the number the
user actually wants to hear.

`get_store_builds` says what can be shipped. On iOS a build is `distributable`
only when Apple has finished processing it — `PROCESSING` means wait, it is
usually minutes. On Android the list is derived from the tracks, so a bundle
uploaded and never assigned to one does not appear; the tool says so in
`limitations`, and those lines are part of the answer, not noise to drop.

## Publishing an Android build

Three calls, and they cannot be collapsed into one.

**1. The build has to arrive signed.** Google pins the upload key's fingerprint
at the first upload, so a bundle signed with anything else is refused. MWM does
not sign a binary it did not build — an app published from the user's own CI is
signed by that CI. Say it plainly before they look for the file, not after
Google refuses it.

**2. `prepare_build_upload`** returns an `upload_url` and an `upload_id`. The
user PUTs the file to that URL themselves — from their browser, their terminal
or their CI. Never read a build into a tool call: a bundle is 50 to 300 MB and
it would be truncated. The file name must end in `.aab` or `.apk`; Google
infers the format from it. The slot expires in 30 minutes.

**3. `get_build_upload`** says what landed: format, size, checksum. Show the
user the size and the checksum, name the package and the track, and ask once.

**4. `publish_build_to_play_track`** takes that checksum back as
`confirm_checksum_md5`. It refuses to publish a file whose checksum was not
confirmed, so a build can only reach Google after it has been looked at. Never
invent that value, and never carry over a checksum from an earlier upload.

The version code is read by Google from the bundle itself. Do not ask the user
for it, do not guess it, and report the one the receipt returns.

### Tracks

| Track | Default status | What it means |
| --- | --- | --- |
| `internal` | `completed` | the internal testers receive it within minutes |
| `alpha` / `beta` | `completed` | the closed or open testers receive it |
| `production` | `draft` | it waits in Play Console for a human to roll it out |

Production defaults to a draft on purpose: it is public, and Google mandates a
manual rollout for an app's first release anyway. Only pass `status` explicitly
when the user asked for that exact behaviour, and say what it changes.

Start on `internal` unless the user named another track. Suggesting a
production publish for a build nobody has tested is not helpfulness.

## What this does not do

- **iOS has no publish tool.** `get_store_builds` lists what is already in App
  Store Connect, but sending an `.ipa` to TestFlight is a different flow and is
  not available here. Say so; do not offer a workaround with another tool.
- **Submitting an iOS version for App Review is the store-publish skill's**
  (`get_store_submission`, then `submit_store_version_for_review`), and so is
  what follows App Review on iOS (`manage_store_release`: release, withdraw,
  phased release). No Play rollout is started, paused or resumed: that stays
  in Play Console today.
- **No build is created.** These tools ship a binary the user already has.

## When it fails

- `not connected` — call `get_store_connections`, let the user connect, retry.
  `prepare_build_upload` checks this before handing out a slot, so the failure
  arrives before the upload, not after it.
- The slot is empty — the PUT has not happened or did not finish. Ask the user
  to upload again; do not publish.
- The checksum does not match — the file changed between the read-back and the
  publish. Call `get_build_upload` again and confirm the current file.
- Google expects a different upload key — the bundle was signed with the wrong
  key. Only the user can fix that, in Play Console or in their signing setup.
- The version code is already used — they need to build a bundle with a higher
  one. MWM cannot bump it for them here.

Never retry the publish in a loop: each attempt is a real upload to Google, and
a successful one cannot be undone.

See `references/tool-contract.md` for the parameter contract.
