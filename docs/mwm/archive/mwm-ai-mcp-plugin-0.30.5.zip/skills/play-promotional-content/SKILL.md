---
name: play-promotional-content
description: Design Google Play promotional content (formerly LiveOps) — Android's equivalent of App Store in-app events — offers, time-limited events and major updates, with the MWM MCP tools get_play_promotion_rules, design_play_promotional_content and iterate_play_promotional_content. Use whenever a UA or marketing user wants a Play promotion for a sale, a season, a live moment, a challenge, new content, a major update or a pre-registration push, or asks for the Google Play side of an in-app event.
---

# Google Play promotional content

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

Promotional content is what Google Play shows on the app's page, in Play's
home and search, and as notifications: a 16:9 image, a tagline, a
description, dates and countries. Three types — offer, time-limited event,
major update — each with its subtypes, and Google reviews every one.

**Google Play has no API for promotional content.** The tools design and check
the draft; they never write it to Play Console. Never claim a content is
created, scheduled or submitted on Google Play. The reviewed draft is entered
in Play Console afterwards (by hand, or through Google's CSV import).

| Tool | Does |
| --- | --- |
| `get_play_promotion_rules` | types, subtypes, durations, schedule, text and image rules — free |
| `design_play_promotional_content` | generates the 1920x1080 image without text and checks the whole draft — one generation |
| `iterate_play_promotional_content` | retouches the image, replaces the texts, or only re-checks the draft (free without `change_prompt`) |

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a quote from it, and never a sentence of the form "the skill requires". When
you need a decision, ask one question in the user's language, with numbered
options when there are several, at the end of your message, then stop.

## The flow

1. **Rules first.** `get_play_promotion_rules` once per conversation.
2. **Know the app.** Description and category from `get_play_store_listing`
   (or `get_public_store_listing`), and one real phone screenshot of the app
   for `app_screenshot_url`, so the artwork shows the actual product.
3. **Pick the type and subtype with the user**:
   - a price cut, more for the price, a reward, a trial → `OFFER`
     (`DISCOUNT`, `VALUE_ADD`, `OFFER_REWARD`, `SUBSCRIPTION_TRIAL`);
   - something that happens for a while → `TIME-LIMITED_EVENT`
     (`COMPETITION_CHALLENGE`, `REAL-TIME`, `SPECIAL`), 30 days at most;
   - a release worth announcing → `MAJOR_UPDATE` (`FEATURES_&_ANNOUNCEMENTS`,
     `NEW_CONTENT`), a set 28 days; `PRE_REGISTRATION_UPDATE`, a set week.
   When the same moment also runs on iOS as an in-app event, keep one theme
   and one look across both, and pass the App Store event card as
   `style_reference_url`.
4. **Write the texts** per language: a tagline (80 characters; 48 when the
   user wants the Spotlight format, 23 in Japanese, Chinese or Korean) and a
   description (500). An offer's tagline says what is discounted and by how
   much. You write them; the tool counts them.
5. **Dates in the user's time zone**, passed as RFC 3339 with the offset; the
   draft returns them in UTC, as Google wants them. Check the calendar with
   the user before designing: a start more than 24 hours away at the very
   least, 4 days for Google's review, 14 days when featuring is requested,
   60 days at most. Featuring uses the quarter's quota — ask before setting
   `featuring_requested`.
6. **Design** with one `design_play_promotional_content` call. The image never
   carries text, a logo or the event name — Google lays its own texts and the
   app icon on top — and keeps its subject inside the safe zone. The Google
   Play studio opens on the draft: the image with the safe zone drawn over
   it, the texts per language with counters, the dates in local time and UTC,
   and a copy button on every field. The user's edits there are re-checked on
   the fly and reach your context: work from that version.
7. **Iterate** with `iterate_play_promotional_content`, always passing the
   previous `draft` back with the user's edits: `change_prompt` for the image,
   `texts` for new copy, nothing to re-check after an edit.
8. **Show the result**: image, texts with their counts, type, dates in the
   user's time zone and in UTC, countries, the issues to fix and the warnings.
   Ask whether to iterate or keep it. Nothing more happens on Google Play from
   here.

## Rules that are easy to miss

- Offers cannot be previewed; other types can show up to 14 days early.
- Every start date of one content falls in the same calendar quarter.
- `user_eligibility` (`EVERYONE`, `NEW_USERS_ONLY`) exists for offers only.
- A video is a public YouTube id, landscape, with monetization off.
