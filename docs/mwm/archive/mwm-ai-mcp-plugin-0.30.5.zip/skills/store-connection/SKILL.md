---
name: store-connection
description: Check the user's App Store Connect and Google Play connections with get_store_connections and guide external setup in MWM Console. Use before accessing the user's own store resources, after a not-connected error, or when the user asks to connect or replace a store integration.
---

# Store connections

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

Use `get_store_connections` on the `mwm-ai` MCP server to read connection status.
The tool returns `app_store`, `play_store`, non-secret account identifiers and
`setup_url` links to MWM Console. It does not open a credential collection panel.

## External setup

When a store is missing, give the user its returned `setup_url` and explain that
configuration happens in their browser on MWM Console. Wait for them to complete
setup, then call `get_store_connections` again to verify the result before
continuing the requested store operation.

If the tool is unavailable, restore MCP access with the setup workflow before
retrying this check. A missing MCP connection does not tell you whether a store
is connected. Do not claim the check succeeded until the tool returns.

## Credentials

Never request or accept passwords, API keys, `.p8` files, service-account JSON,
or MFA/OTP codes in the conversation or an MCP interface. Do not call
`save_app_store_connection` or `save_play_store_connection`: these are no longer
exposed by the server. Credential entry and removal belong to MWM Console.
If a secret is pasted into chat, do not repeat it; advise revoking it with the
issuer and configuring a replacement through Console.

## Multiple accounts

`app_store_accounts` may contain multiple connected Apple accounts. Listing and
publishing tools resolve the account for the selected app. If an app-specific
call fails with an access or scope error, explain that its account or permissions
may differ; do not blindly retry or guess credentials.

Connecting a store does not authorize an unrelated publication or write.
Continue only within the user's requested task and the destination tool's
confirmation requirements.
