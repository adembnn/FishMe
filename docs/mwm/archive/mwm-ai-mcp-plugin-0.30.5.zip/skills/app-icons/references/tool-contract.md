# App icon tool contract

## `generate_app_icons`

- `app_description` is required;
- `user_prompt`, `brand_colors`, `style_id`, `quality` and `model` are optional;
- `count` accepts 1–6 and defaults to 4;
- `quality` accepts `low`, `medium`, `high` or `auto`;
- omit `style_id` unless the user supplied a known supported identifier —
  omitting it spreads the batch across several styles;
- the host renders the interactive icon grid from this result.

## `iterate_app_icon`

- `current_icon_url` is required — the `image_url` of an existing proposal;
- `change_prompt` is required — the requested modification;
- `brand_colors` and `model` are optional;
- the host renders the interactive icon grid from this result.

The structured output of `generate_app_icons` also carries `available_styles`:
the catalogue of supported `style_id` values with their display names. Read it
there rather than guessing an identifier — an unknown one silently falls back to
`flat_minimalist` upstream.

Every proposal carries a durable full-resolution `image_url` in the structured
output. The text content repeats the same URLs as a fallback for hosts that do
not render MCP Apps.
