---
name: app-icons
description: Generate and refine mobile app icons through the MWM MCP tools generate_app_icons and iterate_app_icon. Use whenever a new app or project is being created, when its visual identity is being decided, when an existing icon needs reworking, or when a project has no icon yet and the next step needs one.
---

# App icons

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

This skill covers app icon generation with the `generate_app_icons` and
`iterate_app_icon` tools of the `mwm-ai` MCP server.

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: a draft, something visible on the
  store, something that goes to App Review, something that costs generations.
  Say it as a fact of the work, in your own words, never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## When to offer it

Offer icon generation without waiting to be asked when:

- a new app or project is being created;
- the visual identity is under discussion (palette, style, logo);
- a project has no icon yet and a later step needs one;
- an existing icon is judged unsatisfactory.

Offer it **once**, in one sentence, and proceed if accepted. Every generation is
a billed call to the ASO AI service: never re-run a generation nobody asked for.

## Before generating

The tool only requires `app_description`, but the quality of the result depends
mostly on what you give it. Gather what the context already holds before asking
any question:

| Parameter | Where to get it |
| --- | --- |
| `app_description` | what the app does, its audience, its positioning |
| `user_prompt` | an explicit creative constraint ("a single symbol", "no text") |
| `brand_colors` | the project's design-system palette, as hex values |
| `style_id` | **omit by default**: each proposal then comes out in a different style. Set it only when a specific style is already settled — the whole batch will be rendered in that one |
| `count` | 1 to 6, defaults to 4 |
| `quality` | `low` to explore, `high` to finalize |

If the app description is missing, ask **one** short question. Never invent a
brand palette: with no known colors, omit `brand_colors` and let the service
decide.

See `references/tool-contract.md` for the full parameter contract.

## Generating

One `generate_app_icons` call per turn. To explore widely, raise `count` — not
the number of calls.

The result renders as an interactive grid; hosts that cannot render it receive
the icons as images plus their URLs as text. So don't restate the proposals one
by one: summarize in a single line — how many, and in which style — then ask
which one to keep rather than choosing for the user.

Three things never to do in your reply:

- **never re-display an icon as a markdown image** (`![…](url)`): the grid and
  the tool result already handle it, and hosts don't load remote images into the
  conversation — you would only get an empty frame;
- a **plain link** per proposal is enough if you want them downloadable — never
  an image, never a raw URL spelled out;
- never mention the token cost (`usages`): it is internal data and of no
  interest to the user. Surface it only on request.

If `generate_app_icons` remains unavailable after connection recovery, report
the error and stop generation. Never
fabricate icons with another image generator: the result would be neither in the
right format, nor hosted on the CDN, nor usable by the rest of the flow.

## After validation

The returned `image_url` is a durable CDN URL, suitable as the project's icon
reference and for store publishing metadata. Persist nothing on your own:
propose the next step and let the user confirm.

## Iterating

`iterate_app_icon` starts from an existing proposal instead of regenerating
everything: pass the target icon's `image_url` as `current_icon_url` and the
requested change as `change_prompt`. The rest of the design is preserved, so
always prefer iterating when the user wants to adjust an icon rather than
generating a new batch.

When the user says "that one" or "the second one", resolve the URL from the
previous turn's proposals, or from the icon the grid flagged as selected. Don't
guess: when in doubt, ask.

An iteration is billed like a generation: one per turn, and never on your own
initiative.

## Requests coming from the grid

The grid is a studio: the user picks the style, the count, the colors and the
change there. It sends you **two kinds of message, and they ask for opposite
things** — read the first line.

**An instruction**, when the user asks for a new series:

> Generate a new series of icons by calling `generate_app_icons` with exactly
> these parameters: …

**A report**, when the studio already did the work itself — it iterates in
place, without going through you:

> I generated N icon(s) from the studio: …
> I got this variant from the studio: …

A report ends with "call no tool, just take note of them". Do exactly that:
acknowledge in one sentence and stop. Re-generating on top of a report bills a
batch nobody asked for.

On an instruction, call the named tool **once**, with the listed values and
nothing else:

- don't enrich the brief and don't rephrase the requested change;
- don't alter `count`, `style_id` or the colors — the user chose them in the
  interface. A missing `style_id` is a deliberate choice (the mixed-style
  batch), not an omission to fix;
- don't comment on the result: the grid displays it. One sentence is enough.

Going through you is what gives every batch and every variant its own block in
the conversation. Without it the user would lose their icons on reload: the
interface is destroyed at the end of the turn.
