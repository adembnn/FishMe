# Custom product pages — tool contract

All tools require an authenticated MWM account and the user's App Store
Connect key (`get_store_connections`). `store_id` is the numeric App Store id.
Locales are App Store Connect locales (`en-US`, `fr-FR`, `ja`).

## `get_custom_page_opportunities`

- `store_id` — required; `country_code` (default `US`), `locale` (one App
  Store Connect locale; default every locale of the version), `skip_market`.
- Reads the keyword field of the iOS version that is live (the only one Apple
  serves pages on; the relevant draft when nothing is live yet) and the
  existing pages, then scores each keyword with
  market intelligence for the app on `country_code` / `ios-phone`.
- Returns `version_id`, `version_state`, `primary_locale` (the app's primary
  language, which every page must include), `pages`, `pages_left`, `keywords[]
  { keyword, locale, used_by_page, used_by_page_name, has_market, popularity
  (0-10), difficulty (0-100), rank, opportunity_score, traffic_percent }`,
  sorted by traffic share then demand, and `notes[]`. `has_market: false`
  means the app does not rank for the keyword there: a page would not be
  served.

## `preview_custom_product_pages` — free

- `store_id`, `pages[]` (1–6) — required; `app_name`, `current[]` (the
  product page's `screenshot_sets`) — optional.
- `pages[] { name, intent, localizations[] { locale (default en-US),
  promotional_text, keywords[], screenshot_sets[] { device_preset
  (iphone_67 or ipad_129), screenshots[] { url, thumbnail_url, caption } } } }`
  — one `localizations` entry per locale (same shape as create), one
  `screenshot_sets` entry per device inside it. At least one locale must
  carry an iPhone slot.
- `pages[].header { header_url, search_results_url, universal_url,
  media_type (image|video), poster_url }` — the page's App Store header from
  `design_app_store_header`; `current_header` (same shape) for the main
  product page. Shown above the screenshots; the studio retouches, animates
  and places it.
- Validates like create (locale form, 170 characters, 1–10 screenshots per
  slot, unknown or duplicate slot, duplicate locale, a keyword on one page
  per locale), flags keywords absent from that locale's captions and text,
  and flags a locale missing a device slot `current` has (the page would
  fall back to the screenshots already on the store there). Returns the
  pages echoed with `issues[]`; opens the pages studio. Writes nothing.

## App Store header tools

- `design_app_store_header` — `app_name`, `app_description` required;
  `store_id`, `concept`, `headline` + `language`, `brand_colors[]`,
  `icon_url`, `screenshot_urls[]` (first 3 used), `style_reference_url`.
  `series[]` (the page's screenshots, echoed for the screenshot studio).
  Returns `creative { universal, header, search_results, media_type: image }`
  — one 5244×2950 PNG, the same URL in all three: Apple takes it for both
  placements. Billed as one generation; writes nothing.
- `iterate_app_store_header` — `image_url` (the universal URL),
  `change_prompt`; same output with `previous`.
- `animate_app_store_header` — only when the user asks for a video.
  `image_url`, `app_name`, optional `motion`, `duration_seconds` (8–10,
  default 10); `store_id`, `image` (the creative) and `series[]` when the
  screenshot studio asks for it. Returns `task_id`, `poster_url`. One
  generation; Apple takes no common video for both placements (header 21:9
  only, search results 3:2 only), so the clip is cropped into two MP4s.
- `get_app_store_header_video` — `task_id` (+ `poster_url`) for a generated
  video, or `video_url` for one the user uploaded (cropped and looped the
  same way). Free; a poll can wait up to 40 s while the clip is sized.
  `status` queued / running / succeeded (with `creative`, MP4s: header
  3840×1646, search results 2880×1920, 30 fps, ≥ 15 s) / failed. When the
  screenshot studio started it, the studio polls; do not poll from the chat.
- `show_app_store_header` — `creative`, optional `video`, `show_video`,
  `series[]`, `store_id`, `app_name`: reopens the header in the screenshot
  studio as it was left, so the conversation keeps it. Generates nothing,
  free; the studio asks for it when a video is ready.
- `list_app_store_header_targets { store_id }` — `targets[] { target:
  app_store_version | custom_product_page, custom_page_id, name, state }`.
- `update_app_store_header` — destructive. `store_id`, `target` required;
  `custom_page_id` for a custom page; `locales[]` (omit for every
  localization); `header { url, media_type }`, `search_results { url,
  media_type }`. Uploads to the app's asset library, then places per locale,
  replacing the current one. Returns `status` (ok / partial / failed),
  `placed[]`, `failures[] { locale, placement_type, error }`. Nothing is
  submitted. "no editable version" on the main page: a new version must be
  created in App Store Connect first.

## `list_custom_product_pages`

- `store_id` — required; `include_details` — also each locale's promotional
  text, keywords and screenshot slots (two calls per locale).
- Returns `pages[] { id, name, url, visible, version_id, state, deep_link,
  localizations[] }`, `primary_locale`, `pages_left`, `console_url`.

## `get_custom_product_page`

- `store_id`, `page_id` — required.
- Returns `page` in full — `localizations[] { locale, promotional_text,
  keywords[], screenshot_sets[] { display_type, screenshots[] { url,
  thumbnail_url, state } } }` — plus `ready_for_submission` and `missing[]`.
  Version states: PREPARE_FOR_SUBMISSION, READY_FOR_REVIEW, WAITING_FOR_REVIEW,
  IN_REVIEW, ACCEPTED, APPROVED, REPLACED_WITH_NEW_VERSION, REJECTED.

## `create_custom_product_page` — destructive

- Required: `store_id`, `name` (internal, unique per app), `localizations[]`
  with at least one locale carrying an `iphone_67` screenshot set — unless
  `copy_from_current_page` is set — and always one in the app's
  `primary_locale`, with or without `copy_from_current_page` (refused before
  Apple otherwise).
- Optional: `copy_from_current_page` (seed every locale and slot from the
  product page, then apply the localizations given), `deep_link`, `visible`
  (default true).
- `localizations[] { locale, promotional_text (≤ 170), screenshot_sets[] {
  device_preset: iphone_67 | ipad_129, urls[] (1–10, store order) },
  keywords[] }` — one `screenshot_sets` entry per device; pass both
  iphone_67 and ipad_129 when the product page has an iPad series, so the
  page is cross-device. A slot given is the whole slot as it must end up,
  written incrementally: a URL `get_custom_product_page` returned for that
  slot (url or thumbnail_url) keeps the screenshot without re-uploading it,
  any other URL is uploaded, a screenshot of the slot not in the list is
  removed, then the order given is applied. An App Store (`mzstatic.com`) URL
  that is not in that slot is refused and the slot is left unchanged (a
  `screenshots` failure). An iPhone slot also removes the locale's other
  iPhone sets (Face ID, Large Display, …), so the store shows only that series on iPhone.
  Keywords are added and removed one by one on Apple's side; the result is
  the list given. They must be in the live version's field for that locale
  and free of another page.
- Checks before Apple: locale form, text limit, slot sizes, iPhone slot,
  keyword eligibility, unique name, cap of 35.
- Server sequence: page → editable version → per locale: text, each slot
  (remove the screenshots left out, reserve / upload / commit each new one,
  apply the order), keywords → read back.
- Returns `status`, `page`, `ready_for_submission`, `missing[]`. A late failure
  returns an **error** naming the page id: the page exists, incomplete.

## `update_custom_product_page` — destructive

- `store_id`, `page_id` — required; any of `name`, `visible`, `deep_link`,
  `localizations[]` (same shape; a locale is created when new; `keywords`
  given replace that locale's keywords; a page may keep its own keywords).
- One screenshot changes alone: pass the slot's URLs from
  `get_custom_product_page` in order with the new URL in place of the old one
  (replace), at its position (insert), without it (remove), or in a new order
  (reorder — nothing is uploaded).
- Opens a new version when the current one is approved; refuses while a
  version is WAITING_FOR_REVIEW or IN_REVIEW.

## `delete_custom_product_page` — destructive

- `store_id`, `page_id` — required. Pages never approved only; hide approved
  pages with `visible: false`.

## `submit_custom_product_page` — destructive

- `store_id`, `page_id` — required.
- Refuses when the version is not editable, when no locale has an iPhone slot
  with screenshots Apple accepted (COMPLETE), or when a promotional text is over
  170. Creates a review submission (or joins the one waiting) with the page
  version as item, and submits.
- Returns `submission_id`, `version_id`, `state`, `console_url`.

## Shared failure messages

- "App Store Connect is not connected: call get_store_connections" — no key.
- "does not serve /api/asc/v2/custom-pages yet: deploy it" — the environment's
  publisher-asc predates the routes; not an Apple error.
- "… not in the current version's keyword field" — only those keywords can
  target a page; add them to the field and ship a version first.
- "already served by another page" — a keyword targets one page; move it with
  update on that page.
- "page … was created but is incomplete" — fix with update or delete; never
  create again.
