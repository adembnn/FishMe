---
name: custom-product-pages
description: Grow App Store user acquisition with custom product pages targeted by search keyword, using the MWM MCP tools get_custom_page_opportunities, list_custom_product_pages, get_custom_product_page, create_custom_product_page, update_custom_product_page, delete_custom_product_page and submit_custom_product_page together with the screenshot tools, and give each page — and the main product page — its iOS 27 App Store header and search results visual with design_app_store_header, iterate_app_store_header, animate_app_store_header and update_app_store_header. Use whenever a UA or growth user wants more downloads from search, wants pages per audience or campaign, asks what to do with their keywords, or wants the agent to propose and build UA improvements on its own.
---

# Custom product pages by keyword

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

A custom product page (CPP) is the App Store product page with different
screenshots, preview and promotional text; name, subtitle, description and
icon stay those of the main page. Apple allows 35 per app. Each page has a
`ppid` URL for campaigns and, since 2025, can be **served on search keywords**:
tick keywords of the current version's keyword field on the page, and users
searching those words land on that page instead of the default one. That is
the UA lever: one page per search intent, whose first screenshot answers the
query.

| Tool | Does |
| --- | --- |
| `get_custom_page_opportunities` | the keyword field of the current version, each keyword scored (traffic share, demand, difficulty, rank) and marked when a page already holds it; pages left under the cap |
| `preview_custom_product_pages` | opens the pages studio on every proposal at once — one tab per page next to the current page — free; the user compares and can create from there |
| `show_custom_product_pages` | reopens all saved pages together with full screenshots and current statuses; use once after a completed save batch |
| `list_custom_product_pages` | the pages with state, URL, and with `include_details` their locales, keywords and screenshots |
| `get_custom_product_page` | one page in full, with readiness for review |
| `create_custom_product_page` | page + locales + screenshot slots + keywords — destructive |
| `update_custom_product_page` | name, visibility, deep link, texts, a slot, keywords — destructive |
| `delete_custom_product_page` | a page never approved — destructive |
| `submit_custom_product_page` | to App Review — destructive, outward-facing |
| `design_app_store_header` | the page's iOS 27 header (21:9) and search results visual (3:2), from its intent, screenshots and icon — billed as one generation |
| `iterate_app_store_header` | retouches a header; `animate_app_store_header` + `get_app_store_header_video` turn it into a seamless looping video |
| `list_app_store_header_targets` | the main product page and the custom pages a header can go to |
| `update_app_store_header` | places a header (image or video) on the main product page or a custom page — destructive |

Visuals come from the screenshot tools (`store-screenshots` skill): the page
tools only take URLs.

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: a draft, something visible on the
  store, something that goes to App Review, something that costs generations.
  Say it as a fact of the work, in your own words, never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## The pilot: propose, then build

When the user asks to improve acquisition, wants ideas, or says "do it", run
this loop rather than waiting for instructions step by step.

1. **Audit in one pass, and look.** `get_app_store_listing` with
   `include_images: true` (description, and the actual current screenshots
   as images — not just their URLs), `get_custom_page_opportunities` (the
   scored keyword sheet), `list_custom_product_pages`. Optionally
   `search_market_apps` on the top keywords to see who ranks there and
   `get_public_store_listing` (also with `include_images: true`) on one or
   two of them to see what converts on that query. Reading the description
   tells you the features; looking at the screenshots tells you which ones
   are already staged and how (a tuner dial, a chord diagram, a stats
   graph, a level map) — the concepts in step 2 build on what you saw, not
   on a guess from the text alone.
2. **Group by intent, not by word.** Keywords that mean the same thing go to
   one page: "screentime, reduce, phone, addiction" is one intent; "adhd,
   focus" another; "block, limit, quit" a third. Respect the count the user chose (1 to 6); suggest a count only when unspecified. Rank the
   groups by the sum of traffic share, then demand, and prefer keywords the
   app already ranks for — a page is only served on keywords where the app
   appears. Skip keywords another page holds, or propose moving them.
3. **Propose, with numbers.** One short list: for each page, its name, the
   keywords, the intent in one sentence, the **visual concept** in one line
   (see "One concept per page"), the first screenshot's headline, the
   promotional text. If the user already requested generation with a clear
   count and direction, proceed. Otherwise ask once which concepts to render;
   each screenshot is billed. An accepted choice covers the preparation:
   do not ask again per page, device or batch.
4. **Prepare every complete page in the background, then show one comparison.** Check
   `get_app_store_listing` with `include_images: true`: does the product page
   have an iPad series (`screenshot_sets` with an `ipad_129` slot)? If so,
   every page you propose needs one too — a page missing it falls back to
   the product page's **old, untouched** iPad screenshots next to a new
   iPhone series, and looks unfinished. For the page's intent, produce the
   screenshots for **every page and every device in a single
   `prepare_screenshot_variants` call**: `base_series` carries the current
   series of each slot (iphone_67, and ipad_129 when the product page has
   one), `variants` carries one entry per page — its label, the concept as
   `change_prompt` (scene, background, subject, palette, what changes and
   what stays) and `captions`, one headline per screenshot. Three pages on
   two slots come back as six labelled series in one result, rendered in
   parallel. This tool returns data without a screenshot panel. Keep every
   screenshot from each source series, not just the first two or three.
   Above 40 renders, split by variants or device slots; combine every batch
   before presenting. Never shorten a series to fit the per-call limit.
   Do not open an intermediate screenshot studio or display intermediate
   images and URLs. Never
   a `change_prompt` that puts the same sentence on every screen: headlines
   go in `captions`. Use `iterate_store_screenshots` only to retouch a single
   series afterwards. Reorder so
   the first screen answers the query, or design a new first screen with
   `design_store_screenshots` when none fits. Run the promotional texts
   through `lint_store_text` with `fields: ["promotional_text"]`, fixing
   blocking findings in the background. No separate text review UI. Give
   every page its **App Store header** in the same background pass (see "The
   App Store header"): one `design_app_store_header` per page, `concept` =
   the page's intent, `screenshot_urls` = the page's new first screenshots,
   `icon_url` the app icon — and one for the main product page when the user
   asked for it. Then
   **one** call to `preview_custom_product_pages` with every page — name,
   intent, and `localizations` (one entry per locale, at least the app's
   `primary_locale`, each with its promotional text, its keywords and its
   `screenshot_sets`, one entry per device you rendered) and its `header`
   (`header_url`, `search_results_url`, `universal_url` from the design
   result) — and the current product page's `screenshot_sets` in `current`,
   with `current_header` when you made one for the main page. The studio opens
   on the first proposed page, with one tab per variant next to the current
   page and all its screenshots, device tabs inside each
   (iPhone / iPad) so the user checks both and sees a page flagged when it
   still misses a device the current one has; the user compares, edits the
   text, and can refine one image, a selection or the whole device series
   directly in the panel by describing the change. Edits use the screenshot
   tools, preserve the other proposals, and can be undone before saving.
   Retouching does not authorize store writes. The user creates from the
   panel ("Create this page" / "Create the
   remaining pages") or tells you which ones. For hosts without panels,
   the tool returns contact sheets of the complete series; do not repeat
   their URLs in the message. STOP after the preview and offer the real choice:
   "Tu veux corriger les images ou les textes, ou enregistrer ces pages en
   brouillon dans App Store Connect ?" Wait for the answer before any store
   write. A request to generate, approval of concepts, selection of a variant,
   or a general go-ahead before seeing the result authorizes preparation only.
   If the user chooses iteration, make the changes, show the revised preview,
   then offer the same choice again. Save only after the user explicitly
   chooses to save that reviewed version, or uses the panel's create action.
   Do not submit for App Review without a separate explicit request.
   When you create yourself,
   `create_custom_product_page` with
   `copy_from_current_page: true` so the untouched locales stay as on the
   main page, and `screenshot_sets` with one entry per device you built — a
   slot given is the whole slot, so no old capture lingers on either iPhone
   or iPad. To change one screenshot of a saved page later, read it with
   `get_custom_product_page` and pass that slot's URLs back with only that
   one swapped, moved or left out: the others stay as they are on Apple. The
   studio places a page's header itself right after creating the page; when
   you create, place it after with `update_app_store_header` (`target:
   custom_product_page`, the new `custom_page_id`). Each page needs at least its locale and
   promotional text: Apple creates a page with its first localization. When
   the studio created a page, you see the result in context: do not create
   it again.
5. **Keep the complete collection after saving.** Single-page reads and
   writes return data without opening another panel. After the save/update
   batch, call `show_custom_product_pages` once to reopen all saved pages
   with their screenshots and current statuses. Never finish with only the
   last created/read page visible. If some proposals are still unsaved,
   merge returned IDs/states into the full previous preview (or the studio
   snapshot from model context), then call `preview_custom_product_pages`
   with every proposal, saved and unsaved. Do not regenerate the other pages
   or replace them with Apple's saved-only list. Report IDs, URLs, readiness. `submit_custom_product_page` only when the
   user asks, page by page or all at once.
6. **Close the loop.** Say what to watch: conversion of each page versus the
   default page in App Analytics at 14 and 30 days; pages below the default
   get retired or reworked; keywords with demand but outside the field go to
   the next version's keyword field (a draft with `edit_store_listing` where
   the shared listing exists, else `update_app_store_listing_texts`, with the
   user's approval — never touch the field on your own).

## The App Store header

Since iOS 27 the App Store shows a **product page header** at the top of the
page and a **search results visual** instead of the first screenshots — the
first thing a searcher sees. Each custom page has its own, which makes it the
strongest lever of a page by intent; the main product page has one too. It
belongs to the page, like the Play feature graphic to a custom listing: no
separate panel, it shows above the page's screenshots in the pages studio,
where the user retouches it, makes it a looping video and sends it.

- One `design_app_store_header` gives **one image**: a 5244×2950 universal
  PNG that Apple takes for both placements and crops for each (the subject
  stays centred). Retouches and videos start from `universal_url`.
- Apple's best practices are in the generator's prompt; your `concept` must
  follow them too: **one** clear idea a first-time visitor gets at a glance
  (the page's intent, not a list of features), the app's purpose obvious, on
  brand with the screenshots.
- **No text by default**: a text-free visual fits every locale. Give a
  `headline` (2–5 words, in the page's language) only when the user wants one.
- Never ask for prices, discounts, "free", URLs, awards, rankings, "#1",
  Apple recognitions or other platforms: App Review refuses them.
- **No video by default.** A looping video (`animate_app_store_header`) is
  made only when the user asks — "Transform to video" in the studio. Gemini
  Omni Flash renders it in about a minute (stills with people are fine), then
  it is sized for both placements: the image is its first and last frame, the
  motion slow, muted, one generation. The user can also upload their own video
  ("Upload your video"): it is cropped and looped the same way, for free.
- `update_app_store_header` writes to App Store Connect (asset library, then
  the page, per locale, replacing what was there): only after the user chose
  where and confirmed, or clicked in the studio. The main product page takes
  it on its **editable version**. Nothing is submitted: the header waits
  "Ready to submit" with the version or the page.

## One concept per page, not one title per page

A page that only swaps the headlines is a weak page. The searcher typed
"bass tuner": the first screen should *show* a bass. Before rendering, write
a **concept brief** for each page and turn it into the two inputs of
`iterate_store_screenshots`:

- `change_prompt` — the visual concept, shared by the series: the subject or
  scene, the background, the mood, the accent colour, what to keep. It may go
  far: change the instrument, the sport, the room, the season, the time of
  day, the person, the props, the palette. It must keep the app's real UI
  (the phone screen is the product, not an illustration), the brand's type
  and logo, and the layout of the series.
- `captions` — one headline per screen, in the words of the query.

Read the intent, then **look at the app** (`include_images: true` on
`get_app_store_listing`): which of its real features answers the query, and
does a screen already show it? A metronome app whose keyword field holds
"bass, acoustic, electric, tempo, drummer" puts its metronome screen first
every time and only restages the scene around it — the same recipe as the
tuner example below, for whatever the app actually does: a habit tracker
stages its streak screen for "habit, streak, daily", a recipe app stages its
timer screen for "dinner, quick, weeknight". Examples, for a guitar tuner
whose keyword field holds "bass, acoustic, electric, ukulele, chords":

| Page | Concept (`change_prompt`) | First headline |
| --- | --- | --- |
| Bass tuner | "Replace the guitar with a 4-string bass in every scene; deep, dark stage lighting, low-end amber accent; keep the tuner screen, the brand type and the layout." | "Tune your bass in seconds" |
| Acoustic | "Warm wooden room, an acoustic guitar on a stand, soft daylight; natural palette, cream background; same tuner UI." | "Perfect pitch for acoustic" |
| Electric | "Electric guitar, pedalboard on the floor, neon-magenta rim light on a black background; keep the UI." | "Dial in your electric" |
| Chords | "Show the chord-library screen first, a hand on the fretboard behind the phone; light background." | "Every chord, one tap away" |

Recipe:

1. **Feature check.** The concept only stages what the app does. A "bass
   tuner" page for an app that tunes basses is honest; for an app that does
   not, it is a rejection and a bad review.
2. **What changes / what stays.** Say both in the prompt. The generator
   changes what it is told and keeps the rest; an unspecific prompt drifts.
3. **Series coherence.** One concept per page across all its screens: same
   scene family, same accent, so the page reads as one page. The headline is
   what varies from screen to screen.
4. **Reorder.** Put the screen whose feature answers the query first, then
   the usual sequence. Pass the series to `iterate_store_screenshots` already
   in the new order.
5. **New hero when needed.** When no existing screen shows the feature, make
   one with `design_store_screenshots` from the studio's reference screens
   and the concept as `prompt`, then apply the concept to the rest.
6. **Text in the same voice.** The promotional text names the intent in its
   first words: "Bass players: tune fast, play in tune." Run it through
   `lint_store_text` with `fields: ["promotional_text"]`.
7. **Localize the concept, not just the words.** A locale may want a
   different scene (the instrument, the room, the people); say so when adding
   locales.

Show the concept brief in your proposal, one line per page, so the user can
redirect it before any image is rendered.

## Rules that are not negotiable

- Only keywords of the current version's keyword field can target a page, and
  a keyword targets one page. The opportunities sheet is the truth; the create
  tool refuses anything else and names the page that holds a keyword.
- The page must **answer the query**: its keywords appear in the headlines of
  the first screenshots or in the promotional text. A page that does not is
  worse than the default page, not better.
- Promise only what the app does: Apple reviews every page, a headline for a
  missing feature costs a rejection and a week.
- Promotional text is 170 characters; slots take 1 to 10 screenshots; an
  iPhone slot (`iphone_67`) is required unless the page copies the main page.
- Every page carries a localization in the app's **primary language**, the
  `primary_locale` returned by `get_custom_page_opportunities` and
  `list_custom_product_pages`. Never assume `en-US`: an app whose primary
  language is `en-GB` refuses an `en-US`-only page.
- Never create or update a page without an explicit choice to save made after
  the user has seen the latest preview; earlier generation/concept approval
  is insufficient. Offer iteration or saving and wait. Never submit one the user
  has not asked to submit; never create a second page when the first came back
  partial — fix or delete it.
- Keep it to a handful of pages. 35 is a cap, not a target: each page is a
  review, a measurement and a maintenance cost.

## Locales

Everything about a page is per locale: its promotional text, its screenshots
**and its keywords**, because the keyword field itself differs from one
language to the next. `get_custom_page_opportunities` returns the keywords
locale by locale, and scores them on the storefront you pass in
`country_code` — non-English storefronts often have far less competition on
the same intent, which is where a page earns the most.

Start with the app's primary locale — `primary_locale`, not `en-US` by
default: one locale per page, confirmed, created, measured. A page can also
target another storefront's locale, but it always carries the primary one
too (its own keywords from the sheet, and the same screenshots when they are
in that language). When a page works, add locales with `update_custom_product_page`,
one `localizations` entry each, carrying **that locale's own** three things:
the translated promotional text, the screenshots re-rendered in that language
(`localize_store_screenshots` on the page's series, per device), and the
keywords of that locale taken from the sheet — never the English ones
translated by hand, they must match the keyword field Apple holds for that
language.

The same shape works in `preview_custom_product_pages` and
`create_custom_product_page`, so a multi-locale page can be proposed and
created in one go when the user asks for it. The studio shows one tab per
locale, each with its own texts, keywords and device series, and marks a
locale still missing a device the product page has.

## Vocabulary for UA

- **Intent**: what the searcher wants, expressed by several keywords.
- **Traffic share**: the share of the app's estimated search traffic a keyword
  brings today — protect those first.
- **ppid URL**: the page's link for Apple Ads, Meta and influencers; give it
  to the user after creation.

See `references/tool-contract.md` for the parameter contract.
