---
name: play-custom-listings
description: Design Google Play custom store listings — Android's equivalent of App Store custom product pages — for a country, a set of search keywords, pre-registration, inactive users, buyers, Google Ads traffic or a campaign URL, with the MWM MCP tools get_play_promotion_rules, prepare_play_custom_listings and preview_play_custom_listings. Use whenever a UA or growth user wants a tailored Play listing per audience, keyword or campaign, or asks for the Google Play side of a custom product page plan.
---

# Google Play custom store listings

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

A custom store listing is a variant of the Play listing shown to one audience:
its own name, icon, short and full description, feature graphic, screenshots
and video. Up to 50 per app. It is how an Android app speaks to the people a
keyword, a country or a campaign brings.

**Google Play has no API for custom store listings.** The tools design and
check the listing; they never write it to Play Console. Say so plainly when it
matters — the user, or the export step, enters the reviewed draft in Play
Console. Never claim a listing is live, created or saved on Google Play.

| Tool | Does |
| --- | --- |
| `get_play_promotion_rules` | Google's limits, asset boxes and targeting options — free |
| `lint_store_text` | the texts, against Google Play's rules (`store: google_play`) — free, no panel |
| `prepare_play_custom_listings` | renders every listing at once — its feature graphic and its Android screenshots — in parallel, checks them, and opens the Google Play studio on all of them: the final comparison — billed per image |
| `preview_play_custom_listings` | reopens the studio on every listing after a retouch — free |
| `generate_play_feature_graphic`, `iterate_store_screenshots`, `design_play_custom_listing` | retouch one banner, one series, or re-check one listing after the preview — never to build the set |

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a quote from it, and never a sentence of the form "the skill requires". When
you need a decision, ask one question in the user's language, with numbered
options when there are several, at the end of your message, then stop.

## The flow

1. **Rules first.** `get_play_promotion_rules` once per conversation. Never
   quote a limit from memory.
2. **Read the main listing** with `get_play_store_listing` (or
   `get_public_store_listing` when the account is not connected): its texts,
   its screenshots, its feature graphic. The default language is read
   by default; add the language of a country you target in `languages`, and no
   other: each language is several Play calls, for nothing a custom listing
   uses. A custom listing differs from it on
   purpose; it should not repeat it.
3. **Choose the audiences with the user.** One listing per audience, and the
   targeting is what defines it:
   - `SEARCH_KEYWORDS` — the Android side of a custom product page: take the
     keywords from `analyze_market_keywords` (Google Play) or the user's ASO
     plan; group close keywords on one listing.
   - `COUNTRY` — a market that needs its own angle, not just a translation.
   - `INACTIVE_USERS`, `PURCHASE_BEHAVIOR` — win-back and conversion.
   - `GOOGLE_ADS`, `URL` — a campaign's landing listing.
   Respect the number of listings the user asked for.
   Propose them in one short list — per listing: its targeting, title, short
   description, and the visual concept in one line — then ask once which ones
   to build; each image is billed. If the user already asked to generate with
   a clear count and direction, go straight on. An accepted choice covers the
   whole preparation: never ask again per listing, per device or per batch.
4. **Write the texts** for that audience, per language: title (30), short
   description (80), full description (4000). For a keyword listing, the
   keyword belongs in the title or the short description. Lint them all in
   one `lint_store_text` call on `google_play` and fix the blocking findings
   yourself. You write the copy; no tool writes it.
5. **Render and show every listing in one call**:
   `prepare_play_custom_listings` with
   - `base_series`: the main listing's `android_phone` screenshots (2 to 8),
     plus `android_tablet` when the main listing has tablet screenshots — a
     listing without them falls back to the old tablet series;
   - `brand_icon_url` the app icon and `style_reference_url` the main
     listing's feature graphic, so every banner stays on brand;
   - `listings`: one entry per listing — name, targeting, its linted texts,
     `angle` (what its feature graphic sells), `change_prompt` (the concept
     shared by its screenshots: scene, background, subject, palette, what
     must not change — the app's real UI, the brand, the layout) and
     `captions` (one headline per screenshot, in the listing's language, the
     first two carrying the audience's promise).
   The banners and every screenshot render together, then the Google Play
   studio opens on every listing side by side: that is the final comparison.
   Do not call `preview_play_custom_listings` after it, do not open a
   screenshot studio, do not call `generate_play_feature_graphic` or the
   screenshot tools per listing, never repeat image URLs in the message.
   Above 10 listings or 120 screenshots, split into batches. The icon stays
   the main listing's unless the user wants an audience specific one
   (`generate_app_icons`, 512x512, before this step).
6. **Then STOP and ask.** In a few words: what the checks raised (issues
   Play Console would refuse, warnings) and any image that failed to render.
   Then ask whether to retouch images or texts, or keep the listings. The
   user edits the texts in the studio, sees each listing re-checked, and
   copies every field from it; the studio keeps the current version in your
   context: work from it. A retouch touches only what is asked — one banner
   with `generate_play_feature_graphic` (`feature_graphic_url` +
   `change_prompt`), one screenshot with `iterate_store_screenshot` — never a
   new render of every listing; then one `preview_play_custom_listings` with
   every listing, the drafts carrying the new URLs. Nothing more happens on
   Google Play from here: the user enters the kept listings in Play Console.

## Rules that are easy to miss

- Android sizes only: never reuse `iphone_67` or `ipad_129` renders on a Play
  listing — the boxes differ and Google refuses screenshots whose long side
  is more than twice the short one.
- A listing changes the name, icon, descriptions and graphics; privacy
  policy, category and contact details stay the main listing's.
- `GOOGLE_ADS` listings show on AdMob, not on Play search ads.
