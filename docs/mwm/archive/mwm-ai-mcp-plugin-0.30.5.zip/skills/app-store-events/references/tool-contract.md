# App Store in-app events — tool contract

All tools but the rules require an authenticated MWM account and the user's App
Store Connect key (`get_store_connections`). `store_id` is the numeric App
Store id, with or without the `id` prefix. Dates are RFC 3339
(`2026-10-01T09:00:00Z`); the server normalises them to UTC.

## `get_app_store_event_rules`

- No input, no scope, no upstream call.
- Returns `spec`: `badges[] { id, label, use, default_purpose,
  default_priority, default_purchase_requirement }`, `purposes[]`,
  `priorities[]`, `purchase_requirements[]`, `texts[] { id, max_chars }`
  (name 30, short_description 50, long_description 120),
  `media[] { asset_type, min/max width/height, ratio, image_formats,
  video_formats, video_seconds }`, `schedule { publish_window_days: 14,
  max_duration_days: 31, max_published_at_once: 5, max_approved_per_year: 10,
  reference_name_max_chars: 64 }`, `territories[]` (175 alpha-3 codes),
  `locales[]`.

## `list_app_store_events`

- `store_id` — required; `include_media` — optional, also reads every
  localization's media (two calls per locale).
- Returns `events[]` sorted by start, `live` (PUBLISHED + APPROVED),
  `max_live`, `console_url`. With `include_media` the text result lists the
  primary locale's `EVENT_CARD` and `EVENT_DETAILS_PAGE` URLs under each event.

## `get_app_store_event`

- `store_id`, `event_id` — required.
- Returns `event` with `schedules[]`, `localizations[] { locale, name,
  short_description, long_description, media[] { kind, asset_type, url,
  thumbnail_url, state, errors } }`, `ready_for_submission`, `missing[]`.
  Media `state` is Apple's: AWAITING_UPLOAD, UPLOAD_COMPLETE, COMPLETE,
  FAILED. Opens the studio.

## `design_app_store_event`

- `event_theme`, `badge`, `app_description` — required; `store_id`,
  `app_name`, `app_type`, `brand_colors[]`, `language` (default en-US),
  `reference_name`, `start`, `end`, `publish_start`, `deep_link`,
  `territories[]`, `skip_portrait` — optional; `style_reference_url` — the
  card of a past event (from `list_app_store_events` with `include_media` or
  `get_app_store_event`) whose colours and composition the new card follows.
- Generates the card, adapts it to portrait, writes the texts. Returns
  `creative { card_image_url, details_image_url }`, `texts`, `text_issues[]`
  (over-long texts, returned untouched), `draft` (a ready create input with
  the badge defaults, the dates, every storefront, `reference_name` defaulting
  to the theme plus the month), `rules` (the counters). Opens the studio.

## `iterate_app_store_event`

- `event_theme` — required; `card_image_url` + `change_prompt` to retouch
  the card (the portrait is re-adapted); `regenerate_texts: true` +
  `current_texts` to rewrite the texts; `draft` echoed back updated;
  `app_description`, `app_type` — optional.
- Returns `creative`, `previous` (the card before a retouch), `texts`,
  `text_issues[]`, `draft`.

## `create_app_store_event` — destructive

- Required: `store_id`, `reference_name` (≤ 64, unique per app), `badge`,
  `primary_locale`, `start`, `end`, `localizations[]` including the primary
  locale with `name`, `short_description`, `long_description`, and
  `card_image_url` or `card_video_url`, `details_image_url` or
  `details_video_url`.
- Optional: `purpose`, `priority`, `purchase_requirement` (default per badge),
  `deep_link`, `territories[]` (default all), `publish_start` (default the
  earliest allowed: start − 14 days, or now + 10 min), other locales,
  `skip_wait_for_processing`.
- Checks before Apple: every limit and enum, locale form, territory codes,
  date window, uniqueness of the reference name; warns when five events are
  already live.
- Server sequence: event → each localization → each media (download, fit to
  the box, reserve, upload, commit) → wait for Apple's verdict (90 s at most
  per media) → read back.
- Returns `status` (created), `event`, `ready_for_submission`, `missing[]`,
  `warnings[]`. A late failure returns an **error** that names the event id
  and the failed step: the event exists, incomplete. Nothing is submitted.

## `update_app_store_event` — destructive

- `store_id`, `event_id` — required; any of `reference_name`, `badge`,
  `purpose`, `priority`, `purchase_requirement`, `deep_link`; `start` + `end`
  (+ `territories`, `publish_start`) together; `localizations[]` — a locale
  is created when new, patched otherwise, and a media URL replaces the asset
  of that type.
- Returns `status`, `event`, `failures[]`, `ready_for_submission`, `missing[]`.

## `delete_app_store_event` — destructive

- `store_id`, `event_id` — required. Drafts and rejected events only.

## `submit_app_store_event` — destructive

- `store_id`, `event_id` — required.
- Refuses when the event is not DRAFT / READY_FOR_REVIEW / REJECTED, when a
  text or a media is missing on the primary locale, or when a media is not
  COMPLETE. Creates a review submission (or joins the one waiting in
  READY_FOR_REVIEW — `reused_submission: true`), adds the event, submits.
- Returns `submission_id`, `state`, `console_url`.

## Shared failure messages

- "App Store Connect is not connected: call get_store_connections" — no key.
- "connected but its key is unusable on this server" — MWM-side access
  problem; not the user's key.
- "does not serve /api/asc/v2/app-events yet: deploy it" — the
  sparkai-publisher-asc of this environment predates the event routes; not an
  Apple error.
- "reference_name … is already used by event …" — pick another name.
- "event … was created but is incomplete: …" — fix with update, or delete;
  never create again.
