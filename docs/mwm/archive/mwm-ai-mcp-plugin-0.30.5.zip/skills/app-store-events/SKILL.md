---
name: app-store-events
description: Plan, design, create and submit App Store in-app events for the user's own apps with the MWM MCP tools get_app_store_event_rules, list_app_store_events, get_app_store_event, design_app_store_event, iterate_app_store_event, create_app_store_event, update_app_store_event, delete_app_store_event and submit_app_store_event. Use whenever a UA or marketing user wants an in-app event for a launch, a season, a live moment, a challenge, a major update or a seasonal push — from the idea to the event waiting in App Review.
---

# App Store in-app events

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

In-app events are the timed cards Apple shows on the product page, in search
and on the Today tab: a badge (Challenge, Live event, New season…), a landscape
card, a portrait details page, three short texts, dates and storefronts. They
are what a UA team uses to lift visibility around a moment. The
`mwm-ai` MCP server does the whole job through the user's
connected App Store Connect account, the same way the create.mwm.ai wizard does.

| Tool | Does |
| --- | --- |
| `get_app_store_event_rules` | badges and their defaults, text limits, media boxes, date rules, storefronts, locales — free |
| `list_app_store_events` | the app's events with states and dates, and how many are live against Apple's cap of five |
| `get_app_store_event` | one event in full, with each media's processing state; opens the studio on it |
| `design_app_store_event` | generates the card, the portrait page and the three texts; returns a draft; opens the studio |
| `iterate_app_store_event` | retouches the card (portrait re-adapted) and/or rewrites the texts |
| `create_app_store_event` | creates the event, its localization and media in App Store Connect — destructive |
| `update_app_store_event` | changes attributes, schedule, texts or media of an existing event — destructive |
| `delete_app_store_event` | deletes a draft or rejected event — destructive |
| `submit_app_store_event` | sends a complete event to App Review — destructive, outward-facing |

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: a draft, something visible on the
  store, something that goes to App Review, something that costs generations.
  Say it as a fact of the work, in your own words, never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## The flow

0. **Use what the conversation already holds.** A brief from MWM Console
   (the Events tab's "Ask") already lists the app's events from App Store
   Connect, with their ids, states and dates, the free windows and the days
   at Apple's cap, plus the rules' limits. Plan from it: do not call
   `get_app_store_event_rules` or `list_app_store_events` again, and call
   `get_app_store_event` with an id only for an event whose texts or images
   you actually need. Steps 1 and 3 are for a conversation that starts
   without that brief.
1. **Rules first.** Call `get_app_store_event_rules` once per conversation.
   Never quote a limit or a badge from memory.
2. **Know the app.** Take the app's description and category from the listing
   (`get_app_store_listing`, or `get_public_store_listing` when the account is
   not connected yet). `design_app_store_event` needs `app_description` to
   make artwork and texts that belong to this app.
3. **Look at what exists.** `list_app_store_events` before proposing: the
   reference name must be unique, Apple publishes at most five events at
   once, and the dates should not collide with a scheduled one. It returns
   each event's primary language only; `get_app_store_event` returns every
   language of one event when you need them.
4. **Pick the badge with the user**, from the rules' `use` lines: a goal to
   reach is a Challenge, a ranking is a Competition, something happening in
   real time is a Live event, new content in a series is a New season, first
   availability is a Premiere, a release that changes the app is a Major
   update, anything else timed is a Special event. The badge sets purpose,
   priority and purchase requirement by default; do not touch them unless the
   user has a reason.
5. **Design.** One `design_app_store_event` call with the theme in one or two
   sentences (the occasion, the content, the reward), the badge, the dates
   the user gave, the app description, and `language` when the primary locale
   is not en-US. When the app already ran events, stay on brand: call
   `list_app_store_events` with `include_media` (the primary language's
   images), take the `EVENT_CARD` URL of
   the most recent event whose look the user likes (an Apple `…mzstatic.com`
   URL works as is), and pass it as `style_reference_url`. The generator
   keeps its colours and composition and adapts them to the new theme. Show
   the user which past card you took as reference. The studio opens on the result: card, details page, texts
   with counters, dates with the publish window computed, badge and advanced
   fields, storefronts.
6. **Iterate on request.** A change on the card goes through
   `iterate_app_store_event` with `change_prompt`; texts over their limit or
   texts the user dislikes go through `regenerate_texts`. Always pass the
   `draft` from the previous result back, so the user's edits in the studio
   survive. The studio does the same on its own buttons.
7. **Confirm, then create.** Show the user, in plain words, what will be
   created: reference name, badge, dates and the computed publish date, the
   storefronts, the three texts in full, the two images. Wait for an explicit
   yes, asked plainly: "Je crée cet event en brouillon ? Il ne part pas en
   review, tu le relis d'abord dans App Store Connect." Then `create_app_store_event` with the draft. The studio's "Create"
   button does the same call; when the user clicks it you will see the
   result — do not call create again.
8. **Read it back.** The create result carries the event as Apple holds it and
   `ready_for_submission`. Report from that, not from the draft. A partial
   creation comes back as an error naming the event id: the event exists
   without part of its media; fix it with `update_app_store_event` or delete
   it, but never create a second one.
9. **Submit only when asked.** `submit_app_store_event` sends the event to
   App Review; Apple then publishes it on the scheduled date. It is not part
   of "create the event": the user must ask for it, after seeing the created
   event. The tool refuses an incomplete event and says what is missing.

## Localizing an event

There is no localize tool, and none is needed: you translate. Once the
primary locale is confirmed, call `update_app_store_event` with one
`localizations[]` entry per target locale carrying the three translated
texts, each checked against 30/50/120 in that language. Locales without
media of their own show the primary locale's card and details page on the
store; pass `card_image_url` and `details_image_url` in an entry only when
that locale needs different artwork (text on the card, a local visual).
Never localize before the primary locale's texts and artwork are confirmed:
every locale you add is one more to redo.

## Rules that are not negotiable

- Start in the future; end after start, 31 days at most; publish_start in the
  14 days before start. When the user gives no publish date the server picks
  the earliest allowed — say so.
- Texts: name 30, short description 50, long description 120 characters,
  counted in Unicode code points. Over-long texts are returned as generated,
  never cut: rewrite or let the user edit in the studio.
- Both media on the primary locale: the 16:9 card and the 9:16 details page.
  Images out of Apple's box are fitted server-side (scaled down when the ratio
  fits, centre-cropped otherwise); videos are 15 to 30 seconds and go as
  `card_video_url` / `details_video_url` instead of the image.
- Locales are App Store Connect locales (`en-US`, `fr-FR`, `ja`): the rules
  list them. Territories are ISO 3166-1 alpha-3; omit them for every
  storefront.
- Never create an event the user has not confirmed; never submit one the user
  has not asked to submit; never retry a destructive call in a loop.
- Submit at least a week before the event: App Review takes time, and an
  event approved after its start date never shows.

## Working with the studio

The studio shows the draft or the event and calls the tools itself on its
buttons — retouch, rewrite, create, submit. Those calls surface to you as tool
results and as short model-context notes ("event X created as a draft").
Read them; do not repeat the action. When the studio cannot render (a host
without panels), the same information is in the text result: image URLs,
texts with counts, and the draft in `structuredContent`.

## Vocabulary for UA

- **Theme** is the brief for the artwork and texts: what happens, for whom,
  what they get. "Winter challenge: one new beat a day for a week, frost
  sample pack as the reward" beats "winter event".
- **Purpose** is the audience Apple optimises for: new users, active users,
  lapsed users, or everyone. The badge default is right nine times out of ten.
- **Priority HIGH** is for the one event that matters this period: Apple ranks
  it above the app's other events.
- **Reference name** is internal; the store shows the localized `name`.

See `references/tool-contract.md` for the parameter contract.
