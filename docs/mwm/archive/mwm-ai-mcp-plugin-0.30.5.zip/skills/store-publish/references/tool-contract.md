# Store publish tool contract

## The listing MWM keeps (where the server offers these tools)

Scopes nest: `mcp:stores.publish` covers `mcp:stores.draft`, which covers
`mcp:stores.read`. Only the `publish` tools write to App Store Connect, as the
user's assistant settings allow.

- `get_store_listing` (`read`) — `organization_id`, `app_id`, `platform`
  (`ios` or `android`), `check?`, `locale?` (has that language's screenshots
  read when MWM's copy is old). Returns `listing`, `fields[]` (`path`, `locale`, `field`,
  `value`, `live`, `next`, `desired`, `author`, `reason`, `status`, `version`,
  `lint`, `need`, `editable_now`, `reaches_users`), `readiness`, `can_edit`,
  `can_send`, `checking`.
- `edit_store_listing` (`draft`) — `organization_id`, `app_id`, `platform`,
  `idempotency_key`, `reason?`, `ops[]`: `{op: set|revert|rebase, path,
  value?, if_match}`. Paths `locales/{locale}/{name|subtitle|keywords|
  description|promotional_text|whats_new|marketing_url|support_url|
  privacy_policy_url}` and `version/copyright`; screenshot slots
  `locales/{locale}/screenshots/{DISPLAY_TYPE}` (value: JSON list of image
  keys). Google Play (`platform: "android"`): `locales/{language}/{title|
  short_description|full_description}` and `details/{contact_email|
  contact_website|contact_phone}`; a new language needs its three texts. All
  or nothing; a field that changed since it was read refuses the whole call
  with its current state.
- `edit_store_screenshots` (`draft`) — scope fields, `locale`,
  `display_type` (`APP_IPHONE_67`, `APP_IPAD_PRO_3GEN_129`…), `screenshots[]`
  (the whole slot in order, 0 to 10: an image key the listing returned keeps
  it, an https URL is downloaded, size-checked and stored once), `if_match`,
  `idempotency_key`, `reason`. A draft like the texts: send it with
  `send_store_listing`. MWM never leaves a slot shorter while sending.
- `plan_store_send` (`draft`) — same scope fields, `paths?`. Returns `items`
  (sendable: `before`, `value`, `author`), `blocked` (with `blocker`:
  `store_changed`, `lint`, `clear_unsupported`, `needs_version`,
  `field_locked_in_state`, `language_not_in_version`, `not_on_first_version`,
  `already_sending`, `language_incomplete` (Play), `screenshots_not_read`),
  `foreign[]` (Google Play: what someone prepared in Play Console that the
  commit would submit too: never send it yourself, give `approval_url`),
  `missing` (required texts still empty for App Review),
  `effect`, `approval_url` (MWM Console, where the user reviews and sends).
- `send_store_listing` (`publish`) — same scope fields, `idempotency_key`,
  `paths` (required), `plan_hash?` (of a plan you showed), `approval?`
  (`requested` | `confirmed`, only for promotional text). Returns the plan
  fields above plus `send` (`status`, `items[]` with `result`). With
  `store_send: confirm`, nothing is sent and `approval_url` comes back.
- `create_store_version` (`publish`) — same scope fields, `version_string`.
  Returns `id`, `version_string`, `state`. Refused when a version is already
  being prepared.
- `add_store_language` (`publish`) — same scope fields, `locale`, `name?`
  (the app's name there; empty keeps the primary language's). Returns
  `locale` as App Store Connect writes it. Refused without a version being
  prepared.
- `get_store_submission` (`read`) — same scope fields. Returns `version`
  (`version_string`, `state`, `release_type`, `first`), `build` (attached or
  null), `builds[]` (valid, newest first: `id`, `build_number`,
  `uploaded_at`), `open_submission` (`items[]` with `kind`: `app_event`,
  `custom_product_page`, `product_page_optimization`… and `label`: sent to
  App Review together with the version), `missing[]`, `unsent[]` (drafts not
  part of it), `blockers[]` (`no_version`, `not_submittable_state`,
  `in_review`, `no_build`, `missing_texts`), `review` and `review_hash`.
- `submit_store_version_for_review` (`publish`) — same scope fields,
  `review_hash` (from `get_store_submission`, required), `approval`
  (`requested` | `confirmed`), `build_id?` (one of the preview's builds),
  `idempotency_key`. Returns `version`, `submission_id`, `state`, `reused`
  (joined Apple's open submission), `unsent`. Refused with the new preview
  when the submission changed since `review_hash`. `phased_release?`
  (bool): release the update over 7 days, or not (never the first version).
- `manage_store_release` (`publish`) — same scope fields, `action`
  (`release` | `withdraw` | `pause` | `resume` | `complete`), `approval`.
  Returns `action`, `version_string`, `changed` (false: already done in App
  Store Connect, nothing written) and `review` (with `phased_release`).
  In any other state it is refused with the reason in words: the version is
  not waiting for its release, not with App Review, or has no phased release
  running.
- `get_assistant_settings` (`read`) — `settings` and `domains[]` (`domain`,
  `mode`, what `direct` and `confirm` mean). `set_assistant_setting`
  (`publish`) — `domain` (`store_send` | `store_publish`), `mode` (`direct` |
  `confirm`): only the user's own answer.
- A refusal that depends on the user (not chosen yet, approval missing, a
  colleague's draft) comes back as a tool error that says what to ask or do.
- `get_store_send` (`read`) — same scope fields, `send_id?` (latest when
  empty). Returns `status` (`queued`, `running`, `done`, `partial`, `stale`,
  `failed`) and `items[]` with `result` (`sent`, `stale`, `failed`) and
  `error`.
- `get_store_listing_activity` (`read`) — `after?` cursor; what changed and
  who did it, including changes made in App Store Connect outside MWM.

## Direct writes

The five tools below are destructive, idempotent (writing the same input twice
gives the same listing), require an authenticated MWM account and declare the
`mcp:stores.publish` scope. None submits anything for review.

## `update_app_store_listing_texts`

- `store_id` — required, numeric App Store ID;
- `copyright` — optional, the version's copyright line (200 characters at
  most), written once, not per locale; only one the user gave or confirmed.
- `texts[]` — required (an empty list when only `copyright` changes), one entry per locale: `{ locale, name?, subtitle?,
  description?, keywords?, promotional_text?, whats_new?, marketing_url?,
  support_url? }`. Only the fields given are written. `locale` is canonicalised to App Store Connect's form
  (`fr_FR` → `fr-FR`); an unknown locale is refused.
- Caps checked before Apple: name 30, subtitle 30, keywords 100, promotional
  text 170, description 4000, what's new 4000 characters (Unicode code points).
- `marketing_url` / `support_url` must be absolute `http(s)` URLs, refused
  before Apple otherwise; only URLs the user gave.
- Written on the version being prepared or, when there is none, on the one
  waiting for review (texts and copyright only; its screenshots stay locked).
- Returns `store_id`, `synced_locales`, `skipped` (locales Apple refused),
  `failures` (Apple's own reason, per locale and for the copyright) and
  `copyright_written`.
- Fails with "no version being prepared or waiting for review" when the app's
  current iOS version is in review or live.
- Where the shared listing exists, it saves the texts and the copyright as
  drafts, then sends them as `send_store_listing` does (promotional text stays
  a draft).

## `update_app_store_screenshots`

- `store_id`, `locale` — required; `device_preset` (`iphone_67`, `ipad_129`
  or `iphone_duo`) — required unless `display_type` is given;
- `display_type` — optional, only a legacy slot the app still carries
  (`APP_IPHONE_65`, `APP_IPHONE_61`, `APP_IPHONE_58`, `APP_IPHONE_55`,
  `APP_IPHONE_47`, `APP_IPHONE_40`, `APP_IPHONE_35`, `APP_IPAD_PRO_129`,
  `APP_IPAD_PRO_3GEN_11`, `APP_IPAD_105`, `APP_IPAD_97`), as
  `get_app_store_listing` returned it. That slot is cleaned up only: an empty
  list clears it, its own listing URLs are kept, reordered or dropped; any
  other URL is refused before Apple. `APP_IPHONE_67` or
  `APP_IPAD_PRO_3GEN_129` there is refused — use `device_preset`.
- `screenshots[]` — required, 0 to 10 `{ url, caption? }` in store order: the
  whole slot as it must end up, written incrementally. A `url` (or
  `thumbnail_url`) that `get_app_store_listing` returned for this slot keeps
  that screenshot without re-uploading it; any other URL is uploaded; a
  screenshot of the slot not in the list is removed; the order given is then
  applied. Replacing, inserting, removing or moving one screenshot therefore
  touches only that one. An App Store (`mzstatic.com`) URL that is not in this
  slot is refused before anything is written. An empty list clears the slot —
  App Store Connect has no other "remove all screenshots of this slot" call.
- `iphone_67` maps to `APP_IPHONE_67`, App Store Connect's primary iPhone slot,
  named "iPhone with Dynamic Island (Large Display)" (1320×2868, 1290×2796,
  1260×2736) — not `APP_IPHONE_65`, "iPhone with Face ID (Large Display)"
  (1284×2778, 1242×2688), a legacy slot. `ipad_129` maps to
  `APP_IPAD_PRO_3GEN_129`, "iPad 13-inch Display". Each image's pixel size
  is checked against the target slot's known accepted sizes before upload; a
  mismatch (e.g. a Face ID-sized render sent to the Dynamic Island slot) is refused with an
  explicit error instead of uploading and letting Apple silently reject the
  asset after the call already reported success.
- `iphone_duo` has no screenshot set in App Store Connect: its screenshots go
  through the asset library (`APP_SCREENSHOT` placements in the
  `IPHONE_DUO_PROFILE` group, on the editable version's localization). Every
  URL must be a generated image at 2007×2853, 1398×2034, 2853×2007 or
  2034×1398 (checked before upload); App Store (`mzstatic.com`) URLs are
  refused. The Duo slot of that locale is replaced in full, in the order given;
  the other slots are untouched.
- Each URL to upload is fetched before the call to name the file by its real
  content type (Apple parses the extension) and check its size; an unreachable
  URL fails the whole call. Kept listing URLs are not fetched.
- Returns `store_id`, `locale`, `display_type` (`APP_IPHONE_67`,
  `APP_IPAD_PRO_3GEN_129`), `requested`, `kept`, `uploaded_count`, `removed`,
  and `failures[]` (steps Apple refused: an upload, a removal, the ordering;
  the rest was written). `requested: 0` means the slot was cleared, not that
  nothing happened.

## `update_play_store_listing`

- `package_name` — required;
- `listings[]` — required, one entry per language: `{ language, title?,
  short_description?, full_description?, video? }`. Only the fields given are
  written. `language` is normalised (`en` → `en-US`).
- Caps checked before Google: title 30, short description 80, full description
  4000.
- One committed edit per language. Returns `package_name`,
  `updated_languages`, `failed[] { language, error }`.
- When the user has several Play keys, each is tried until one has access to
  the package.

## `update_play_store_screenshots`

- `package_name`, `language`, `device_preset` (`android_phone` →
  `phoneScreenshots`, `android_tablet` → `tenInchScreenshots`) — required;
- `screenshots[]` — required, 1 to 8 `{ url, caption? }` in store order; the
  slot is replaced.
- Images are downloaded by the server and sent to Play as base64.
- Returns `package_name`, `language`, `image_type`, `uploaded_count`.

## `update_play_store_graphics`

- `package_name` — required; `language` optional, defaults to `en-US`;
- `icon_url` and/or `feature_graphic_url` — at least one;
- the icon is resized to 512×512 PNG; the feature graphic to 1024×500,
  flattened on white and encoded as JPEG (Google refuses transparency).
- Returns `package_name`, `language`, `icon_updated`,
  `feature_graphic_updated`.

## Shared failure messages

- "… is not connected: call get_store_connections" — no key for that store.
- "… connected but its key is unusable on this server" — MWM-side access
  problem; not the user's key.
- "the sparkai-publisher-asc service … does not serve the ASO sync routes" —
  environment not deployed; not an Apple error.
