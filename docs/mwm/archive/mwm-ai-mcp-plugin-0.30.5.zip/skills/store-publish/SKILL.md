---
name: store-publish
description: Apply store changes for real — App Store texts through the listing MWM keeps for every editor (edit_store_listing, send_store_listing, create_store_version, get_store_submission, submit_store_version_for_review, manage_store_release, following the user's assistant settings; plan_store_send when they want to review first), and screenshots, the iOS 27 App Store header, icon and feature graphic with update_app_store_screenshots, update_app_store_header, update_play_store_listing, update_play_store_screenshots and update_play_store_graphics. Use whenever the user wants store changes applied — after screenshots were generated or texts were reviewed; screenshots, header and Google Play changes never before the user has confirmed exactly what will be written.
---

# Store publish

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

Six tools on the `mwm-ai` MCP server write to the user's own
listings through the accounts connected with `get_store_connections`:

| Tool | Writes |
| --- | --- |
| `update_app_store_listing_texts` | name, subtitle, description, keywords, promotional text, what's new, marketing URL, support URL — per App Store locale. Where the shared listing exists (below) it saves drafts, then sends them as the user's settings allow |
| `update_app_store_screenshots` | one App Store slot (locale + device) — set to the list given; only what changes is written |
| `update_app_store_header` | the iOS 27 product page header and search results visual (image or looping video) — main product page or a custom page, per locale |
| `update_play_store_listing` | title, short and full description, video — per Play language |
| `update_play_store_screenshots` | one Play slot (language + device) — the whole set |
| `update_play_store_graphics` | Play icon and/or feature graphic |

They do exactly what create.mwm.ai does when it syncs a project. They **do not
submit anything for review**: on Apple the change becomes visible when the
version is submitted and released; on Google, after Google's own review of the
listing edit.

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: a draft, something visible on the
  store, something that goes to App Review, something that costs generations.
  Say it as a fact of the work, in your own words, never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## App Store texts: the listing MWM keeps

When the server offers `get_store_listing`, App Store texts (name, subtitle,
keywords, description, promotional text, What's New, URLs, copyright) live in
one listing every MWM editor shares: the user in MWM Console, other agents,
you. A request like "set my title to X and localize it" goes all the way to
App Store Connect without slowing the user down; what you may do without
asking again is the user's own choice, saved in their MWM account and applied
by the server.

**Their two settings** (`get_assistant_settings`):

- `store_send` — sending listing changes to App Store Connect. `direct`: you
  send. `confirm`: they review each send in MWM Console; `send_store_listing`
  then returns `approval_url` instead of sending, give it to them.
- `store_publish` — submitting for App Review, and promotional text, which is
  public as soon as it is sent. `direct`: when their request says so
  (`approval: "requested"`). `confirm`: ask them first, every time, and act
  on their yes (`approval: "confirmed"`). Never on your own initiative.

When a tool says they have not chosen yet, ask them once, in plain words (the
tool gives both options), save their answer with `set_assistant_setting`, then
call again. Never choose for them. They can change it in MWM Console (AI
Connections).

1. **Read** with `get_store_listing` (`organization_id`, `app_id`,
   `platform: "ios"`). Each field gives its live and next value, any draft and
   who wrote it with their reason, its `status`, its `need` before App Review,
   and its `version`. `readiness` says what App Review still needs.
2. **Write the drafts** with `edit_store_listing`: one op per field,
   `{op: "set", path: "locales/fr-FR/name", value, if_match: <the field's
   version>}` (`""` for a field you saw absent), a `reason` the user will read
   next to the change, and an `idempotency_key` you reuse when retrying. To
   localize, write each language of the version in the same call.
3. **When a field changed since you read it**, nothing is written and the
   answer gives its current value and author. Show the user both texts and
   act only on their choice; never retry over it.
4. **Send** with `send_store_listing`, `paths` = the fields the user asked to
   change. It sends only drafts the user wrote (never a colleague's), follows
   the send until App Store Connect returns the values, and says field by
   field what was written and verified. Nothing is public: the change waits in
   the version being prepared until it is submitted and released.
   - `needs_version`: no version is being prepared. Create it with
     `create_store_version` (the version the user gave, or the live one with
     its last number raised), then send again.
   - `language_not_in_version`: the version lacks that language. Add it with
     `add_store_language` (only a language the user asked for), write its
     texts, then send again.
   - If the send is still running after 20 s, follow it with `get_store_send`.
5. **Report** in a few lines: what is now in App Store Connect, what waits and
   why, what App Review still needs (`missing`).
6. **Submit for review** only when the user's request asked for it or they
   said yes when you asked. First read `get_store_submission` and show the
   user, in a few lines, everything it would send: the version, the build
   (the attached one, or let them choose among `builds`), and every other
   item Apple's open submission already holds (in-app events, custom product
   pages…), which App Review receives together. Say which drafts are not part
   of it (`unsent`: send them first) and what still blocks (`blockers`,
   `missing`). Then call `submit_store_version_for_review` with that
   `review_hash`, the chosen `build_id` and the matching `approval`. If it
   answers that the submission changed, show the new content and ask again.
   Otherwise end by asking whether to submit. For an update, say whether it
   will reach people over 7 days (`version.phased_release`); `phased_release`
   on the submit sets it, only as the user chose.
7. **After App Review**, under the same rule as submitting:
   `manage_store_release` releases a version Apple approved that waits for
   the user's release (`release`), takes one back while Apple reviews it
   (`withdraw`: Apple cancels the whole submission, with its other items),
   or pauses, resumes or completes its phased release (`listing.review.
   phased_release`). Say what it does before acting; `changed: false` means
   App Store Connect had already done it.

When the user says they want to review before sending, use `plan_store_send`
instead of step 4: show the plan in a few lines and give them `approval_url`,
where they review it and send; then `get_store_send`. Sending never submits.
`update_app_store_listing_texts` drafts and sends the same way (promotional
text stays a draft there), but prefer the steps above.

When the server does not offer `get_store_listing`, App Store texts follow the
rule below with `update_app_store_listing_texts`, as do screenshots, the
header and everything on Google Play.

## The rule: read, show, confirm, write, read again

Every one of these tools is destructive. A screenshot list becomes the slot;
a text overwrites the field. So the sequence is fixed:

1. **Read** the current listing with `get_app_store_listing` or
   `get_play_store_listing` (or `get_store_listing_status` when the goal is to
   complete a listing). Never write to a listing you have not read in this
   conversation.
2. **Show** the user, locale by locale and slot by slot, exactly what will
   change: the field, its current value, the new value; the slot, how many
   screenshots today, how many after. Quote texts in full.
3. **Confirm.** Wait for an explicit yes. "Looks good" about the screenshots is
   not a yes to pushing them. If the user asked to push in the same sentence
   that asked to generate, still show the summary and ask once.
4. **Write**, one tool call per locale group or per slot, in the order the user
   sees it.
5. **Read again** with the listing tool and report what the store now holds,
   from that result, not from memory.

## When the request comes from the studio

The screenshot studio has a "Send to the store…" button. It sends you a
message naming the series, its locale and `device_preset`, and asking you to
follow this skill. It does not name the app: resolve it from the conversation
(the listing you read, the store id or package the user gave). Then the same
sequence applies — read the slot, show what will be replaced, wait for the yes,
write, read again. The button is a request, not a confirmation.

## Texts

Where the shared listing exists, App Store texts go through it (above); what
follows covers the direct push and Google Play.

Run `review_store_text` on the texts before pushing them: the push tools check
the character caps and refuse an over-long field, but the review catches what
the caps do not (separators, duplicates, locale form). Send only the fields
that change; an omitted field keeps its store value.

App Store texts need a version **being prepared** (prepare for submission, or
rejected) or **waiting for review**: App Store Connect keeps taking the texts
and the copyright of a version in `WAITING_FOR_REVIEW`, not its screenshots.
Once a reviewer has it (`IN_REVIEW`) or it is live, nothing can be written.
When the tool answers that the app has no version being prepared or waiting
for review, say that a new version must be created in App Store Connect first;
do not try another tool. `get_store_release_status` tells you beforehand: read
the version's state, not only its `stage` — `in_review` covers both waiting for
review, where texts still go through, and in review, where they do not. If
Apple refuses a field on a waiting version, the result quotes Apple: report it
as is. Locales are App Store Connect locales (`en-US`, `fr-FR`, `ja`);
`get_store_text_rules` lists them.

The **copyright** goes through the same tool too (`copyright`, once for the
version, not per locale; `texts` may then be empty). Like the URLs, it comes
from the user or is confirmed by them: never make one up.

The **marketing URL** and **support URL** go through the same tool
(`marketing_url`, `support_url`), per locale. They come from the user only:
never propose, guess or build one from the app name or the developer's domain,
and never copy one locale's URL to the others unless the user asked for the
same URL everywhere. When one is needed and missing — Apple requires a support
URL before submission — ask for it. Read the current values first with
`get_app_store_listing` and show what will change.

Play texts map as the web app maps them: `title`, `short_description`,
`full_description`. Each language is its own edit, committed immediately and
then reviewed by Google.

## Screenshots

The list is the whole slot as it must end up. Pass every screenshot that must
be on the store for that locale and device, in store order, not just the new
ones: what is not in the list disappears from the slot. Read the current slot
first and say so when some existing screenshots are about to go. Passing an
empty list clears the slot on purpose — the only way to empty one, since the
store itself has no separate "remove all" call.

On the App Store, only what changes is written. A `url` that
`get_app_store_listing` returned for this very slot (full size or thumbnail)
keeps that screenshot as it is: it is not downloaded or re-uploaded. So the
small edits are cheap and leave the rest of the slot untouched:

- **Replace one screenshot**: pass the slot's listing URLs in order, with the
  new generated URL in place of the one it replaces.
- **Reorder**: pass the same listing URLs in the new order — nothing is
  uploaded.
- **Remove one**: pass the listing URLs without it.
- **Insert one**: pass the listing URLs with the new URL at its position (ten
  at most).

Show the user the slot before and after, position by position, and say which
ones stay, which are new and which go. An App Store URL taken from another
locale or another slot is refused — the server cannot fetch images back from
Apple's CDN; push the generated screenshot's URL instead. The tool answers with
how many screenshots were kept, uploaded and removed, and any step Apple
refused.

**Older apps and the Face ID slot.** New screenshots only ever go to
`iphone_67` — App Store Connect's "iPhone with Dynamic Island (Large
Display)" — and `ipad_129` ("iPad 13-inch Display"). An older app often still
carries an `APP_IPHONE_65` set ("iPhone with Face ID (Large Display)") — or
Dynamic Island medium, Home Button, older iPad sets — next to it, and
`get_app_store_listing` shows it with its own `display_type` and
`display_name` (its `device_preset` reads `iphone_67` because a large render
could fill it; that does not make it the Dynamic Island slot). After pushing a
new series, point out the legacy set still on the listing and offer to remove
it. Always name slots by their `display_name`, never by the inch size in the
API value. To act on it, call
`update_app_store_screenshots` with that `display_type` instead of
`device_preset`: an empty list clears it, its own listing URLs keep, reorder
or drop its screenshots. Generated URLs are refused there. Clearing it is
destructive like any push: show it and wait for the yes.

On Google Play the slot is always replaced in full: pass the generated URLs,
not the ones `get_play_store_listing` returned.

`device_preset` is the slot the images were rendered for, and it must match
the store: `iphone_67` or `ipad_129` on Apple (rendered at 1290×2796, uploaded
to `APP_IPHONE_67`, App Store Connect's primary iPhone slot — Apple derives
the smaller iPhone sizes from it, not the other way around), `android_phone`
or `android_tablet` on Google. A screenshot rendered for another slot is
refused by the store — its pixel size is checked against the target slot
before upload and the call fails with a clear error rather than uploading a
mismatched image, so never mix slots in one call.

**iPhone Duo.** `device_preset: iphone_duo` pushes a series made with
`adapt_store_screenshots_to_duo` to App Store Connect's iPhone Duo slot (no
classic screenshot set exists for it: it goes through the asset library). The
slot is replaced in full with the generated URLs, in order; sizes are checked
before upload. Same rule: show it, wait for the yes.

Pass the URLs returned by the screenshot tools, plus on the App Store the
listing URLs of the screenshots that stay. One call per locale and slot; a
series in three locales is three calls, each shown to the user beforehand.

## Play graphics

`update_play_store_graphics` takes an `icon_url` and/or a
`feature_graphic_url`. The server resizes the icon to 512×512 PNG and the
feature graphic to 1024×500 opaque JPEG, as Google requires. The feature graphic
is mandatory on Google Play: `get_store_listing_status` says when it is
missing. Generate one with the MWM tools before pushing if the user has none.

## App Store header

`update_app_store_header` uploads the header and search results files to the
app's asset library and places them on the main product page (its editable
version) or on a custom product page (`list_app_store_header_targets`), on
the locales given or every one, replacing what was there. Make them with
`design_app_store_header` (the main page's header opens in the screenshot
studio above the page's series; a custom page's shows with that page in the
pages studio). When the studio asks to send it, list the targets, say which
page and locales it lands on, and wait for the yes. Same rule as everything here: show the target and the locales,
get a clear yes, write, then say it waits "Ready to submit" — nothing is
submitted.

## When a push fails

- "not connected": call `get_store_connections`, let the user connect, retry.
- "key is unusable on this server": an operations problem on MWM's side, not
  the user's key; say so and stop.
- "no version being prepared or waiting for review" (or "no editable
  version"): a new App Store version is needed first.
- Google "refused": the message names the language; the other languages were
  written. Report both.
- App Store screenshot `failures`: Apple refused those steps (an upload, a
  removal, the ordering); everything else was written. Read the slot back and
  name what is missing or out of place.
- "is an App Store image that is not in this slot": a listing URL from another
  locale or device was passed. Use the generated screenshot's URL instead.

Never retry a destructive call in a loop, and never claim a change is on the
store without reading it back.

See `references/tool-contract.md` for the parameter contract.
