# Store screenshot tool contract

## `open_screenshot_studio`

- every field is optional: `app_name`, `prompt`, `device_preset`, `count`,
  `captions` are echoed back as `prefill` and populate the form;
- `screenshots` opens the studio **on an existing series** instead of the drop
  zone: `{ image_url, caption?, thumbnail_url? }` in store order, up to six, with
  `device_preset` (required then) and optionally `language`. This is the path
  for a published app whose screenshots came from the listing tools: the user
  lands on the retouch step, nothing to upload;
- generates nothing and bills nothing;
- returns the series (empty, or the one given with its dimensions),
  `device_preset`, `language` and `available_presets`.

Call it when you need images only the user has, or to open a published series for retouching. Not before a generation you can already run: `design_store_screenshots` and `generate_store_screenshots` open the studio themselves, on their result.

## `iterate_store_screenshots`

- `screenshots` is required — the series in store order, `{ image_url,
  caption? }`, up to ten;
- `change_prompt` is required — the change applied to every screenshot;
- `device_preset` is required — the slot of the series. One slot per call: for
  several devices, `build_screenshot_variants` with one variant and every slot;
- `orientation`, `assets` and `language` are optional, as for the single
  iteration;
- one upstream call per screenshot, in parallel. A failed edit keeps the
  original in place and lists its index in `failed`; the call errors only when
  every edit failed;
- returns `screenshots` (the whole retouched series), `device_preset`,
  `language`, `failed`, `available_presets`. The studio renders it as a series.

## `design_store_screenshots`

- `app_description` is required;
- `hero_screenshot_url` is the one real screen the proposals are designed
  around; omitted, the first entry of `screens` is used;
- `screens` is the whole series being prepared, hero first, as
  `{ url, feature_description }`. Nothing is generated from it at this stage: it
  is **echoed back** in the result, alongside `app_description`, and that echo
  is where `apply_screenshot_design` takes its URLs — the app instance that
  uploaded them no longer exists by then. Up to six entries;
- `device_preset` and `orientation` are optional: omitted, the dimensions of the
  hero screen decide the slot;
- returns three `proposals`, each with `direction` (`Minimalist`, `Bold`,
  `Warm`), `direction_id` and an `image_url`. A direction that fails upstream is
  retried twice, and a set of two is returned rather than an error;
- headlines are drafted in `en-US` at this stage; localization happens when the
  style is applied.

## `apply_screenshot_design`

- `design_screenshot_url` is required — the proposal the user picked;
- `app_description` is required;
- `screens` is required: up to six `{ url, feature_description }`, the label
  becoming the marketing headline of that screenshot. Take them from the
  `screens` echoed by `design_store_screenshots`, minus the hero, which is
  already rendered as the chosen proposal;
- `hero_feature_description` is the label of the screen the style was designed
  on; it becomes the caption of the leading screenshot;
- `device_preset` and `orientation` are optional, probed from the first screen;
- `language` writes the headlines in a given locale;
- the chosen proposal leads the returned series, then the rendered screens in
  order. A screen that fails is skipped, not fatal.

## `generate_store_screenshots`

- `app_name` is required — printed on the screenshots when the scenario asks;
- `prompt` is required — what the series shows and promises, screen after screen;
- `device_preset` is required — `iphone_67`, `ipad_129`, `android_phone` or
  `android_tablet`; the result's `available_presets` lists them with dimensions;
- `orientation` accepts `portrait` (default) or `landscape`;
- `count` accepts 1–6 and defaults to 3;
- `captions` is an array of one line per screen, in order — it overrides the
  prompt for the text drawn on that screenshot;
- `assets` is an array of `{ url, name?, tag? }` reference images; `tag` states
  the role (`screen`, `logo`, `character`, `background`);
- `style_reference` accepts the URL of a screenshot whose style to match;
- one upstream call is made per screenshot, in parallel, each told its rank in
  the series. A partial failure returns the screenshots that succeeded;
- the host renders the interactive studio from this result.

## `iterate_store_screenshot`

- `screenshot_url` is required — the `image_url` of an existing screenshot;
- `change_prompt` is required — the requested modification;
- `device_preset` is required — pass the slot of the original so the edit keeps
  its store dimensions;
- `orientation`, `assets` and `language` are optional; `language` preserves the
  locale of the text already visible on the screenshot;
- `series` is the current series, in order, as `{ image_url, caption?,
  thumbnail_url? }`. Pass it: the result then carries `screenshots` — the whole
  set with the edited screenshot in place of the original, keeping its caption —
  plus `replaced_index`. Without it the result holds `screenshot` alone, and the
  studio that renders it shows one image instead of the series;
- the result also carries `previous`, the screenshot as it was before the edit;
  the studio uses it for a before/after toggle and a "keep the original" action.

## `localize_store_screenshots`

- `slots` — every device of the listing at once: `{ device_preset, screenshots:
  [{ image_url, caption? }], orientation? }`, up to 10 screenshots per slot.
  For a single slot, `screenshots` + `device_preset` works too (not both);
- `target_languages` is required — every locale to produce (`fr-FR`, `ja-JP`),
  up to 40 in one call; `source_language` names the locale of the text on the
  series;
- `captions` optionally imposes the translated caption per screenshot, keyed by
  target locale;
- every (slot, locale, screenshot) renders in parallel in one pool, so the call
  lasts about one render whatever the volume; a series where nothing rendered
  is dropped, a screenshot that failed is counted in `skipped`. Refused above
  400 renders per call (slots x locales x screenshots);
- returns `source_language`, `source` and, with several slots, `sources` (the
  original series of each slot, with its `device_preset`), `series[]`
  (`language`, `device_preset`, `screenshots`, `skipped`), `device_preset`,
  `available_presets`. The studio renders a tab per device and a chip per
  language; `download_screenshot_series` takes `screenshots` (source) plus
  `localized`, one device at a time.

## `adapt_store_screenshots_to_duo`

- `screenshots[]` — required, 1 to 10 `{ image_url, caption?, thumbnail_url? }`:
  the finished iPhone or iPad series, in store order, with its captions (kept
  letter for letter);
- `source_device_preset` — the slot of that series (`iphone_67`, `ipad_129`),
  echoed back as a studio tab;
- `layout_reference[]` — optional, the iPad series of the same listing and
  language, same order, when `screenshots` is the iPhone one;
- `orientation` — `portrait` (default, 2007×2853) or `landscape` (2853×2007);
  `language` — the locale of the text, kept as is;
- every screenshot is adapted in parallel and measured: anything not at the
  exact size is dropped and listed in `failed` (`"3: …"`), the rest kept in
  order. About 50 s per call whatever the count: pass the **whole series of a
  locale in one call, never in batches** — every call opens another studio
  panel;
- a screenshot still rendering after 75 s is cut off and listed in `failed`
  and `failed_positions`: **do not call again for it**. The studio adapts the
  missing ones again by itself, one by one, and puts each back at its place in
  the same iPhone Duo tab. Call again, with only those screenshots, only when
  the studio reports some still missing. When every screenshot was cut off the
  studio still opens and adapts them all;
- returns `series[]` (one, `device_preset: iphone_duo`), `sources[]` (the
  source and the layout reference, as studio tabs), `width`, `height`,
  `language`, `available_presets`, `failed[]`, `failed_positions[]` (0-based)
  and `total` (the series' length). Opens the screenshot studio.

## `prepare_localize_screenshots`

- Same input and same render as `localize_store_screenshots`, silent: no inline
  images, no panel, every URL in `structuredContent` only;
- only for a request `localize_store_screenshots` refuses as too large: split
  the locales into two or three calls fired together, then one
  `preview_localized_screenshots`.

## `preview_localized_screenshots`

- Free — nothing is generated, it only reshapes what is given;
- `sources` (one per slot) or `source`, and `series` (required) — every
  localized series to show together, each with its `device_preset`;
- returns the same shape as `localize_store_screenshots` and opens the one
  studio with a tab per device and per locale. Call it exactly once, with the
  complete combined set.

## `download_screenshot_series`

- `screenshots` is required: the series in store order, `{ image_url, caption? }`
  — only the URL is required, never restate dimensions or MIME type;
- `name` is optional, the base name of the archive (the app name reads well);
- returns `url` — a hosted zip, files numbered in order and named after their
  caption (`02-progress.png`) — plus `count` and `bytes`;
- generates nothing and bills nothing. The studio calls it from its download
  button; call it yourself when the user asks for the files or a zip, instead of
  listing URLs one by one.

## Reference upload — studio only

Two tools serve the studio and are hidden from the model
(`_meta.ui.visibility: ["app"]`):

- `prepare_screenshot_reference` returns a pre-signed `upload_url` plus the
  `asset` the file will become. The studio PUTs the bytes straight to storage —
  nothing transits through the host, so there is no size inflation and no
  truncation. This is the normal path;
- `import_screenshot_reference` is the fallback, used only when the sandbox
  blocks the storage origin: the bytes travel as base64 inside the tool call,
  capped at 6 MB. It rejects a truncated JPEG or PNG rather than accepting a
  half-written file.

Neither is for model use. Images already reachable by URL need no upload at all:
pass them straight into `assets`.

An image the user attached to the conversation is **not** reachable by URL and
cannot be turned into one from your side: the studio's drop zone is the only
import path. Ask for the files there rather than in the chat.

Every screenshot carries its slot dimensions (`width`, `height`) in the
structured output, alongside a durable full-resolution `image_url`. The text
content repeats the same URLs as a fallback for hosts that do not render MCP
Apps.
