---
name: store-screenshots
description: Generate and refine App Store and Play Store screenshots through the MWM MCP tools generate_store_screenshots and iterate_store_screenshot. Use whenever store listing visuals are needed, when a submission is being prepared, when screenshots must be redone for a new device slot, or when an app has no store screenshots yet.
---

# Store screenshots

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

This skill covers store screenshot generation on the `mwm-ai`
MCP server, with tools you can call: `open_screenshot_studio`,
`design_store_screenshots`, `apply_screenshot_design`,
`generate_store_screenshots`, `iterate_store_screenshot`,
`prepare_screenshot_variants` / `build_screenshot_variants`,
`localize_store_screenshots`, `prepare_localize_screenshots` /
`preview_localized_screenshots` and `download_screenshot_series`.

The studio has two more for its own use — uploading reference images — which are
hidden from you on purpose. See the last section.

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: a draft, something visible on the
  store, something that goes to App Review, something that costs generations.
  Say it as a fact of the work, in your own words, never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## When to offer it

Offer screenshot generation without waiting to be asked when:

- a store submission is being prepared and the listing has no visuals;
- the app's positioning or promise changes, making the current series stale;
- a new device slot is required (a tablet build, a second store);
- the user is unhappy with existing screenshots.

Offer it **once**, in one sentence. Every screenshot is a billed generation:
never re-run a series nobody asked for.

## When the app is already on the store

Read the listing before generating anything: `get_public_store_listing` for
any app, or `get_app_store_listing` / `get_play_store_listing` for the user's
own app through the connected account. Each existing screenshot comes back with
its `url` and the `device_preset` it was rendered for. The `store-listing`
skill covers those tools. Starting from the real listing is cheaper and more
faithful than regenerating a series the user already has.

Then **do not open the studio empty and do not iterate image by image.** Two
paths, both one call:

- the user wants to see and drive the retouch: call `open_screenshot_studio`
  with the existing series in `screenshots` (the URLs in store order, one slot
  at a time) and its `device_preset`. The studio opens directly on that series,
  no drop zone, with a "Whole series / This screenshot" switch and the change
  box. The user types the change and the studio does the rest;
- the user already said what to change ("a Christmas theme on all of them"):
  one call for the whole listing. With a single slot, `iterate_store_screenshots`
  with the series, the `change_prompt` and the `device_preset`; with several
  slots (iPhone and iPad), `build_screenshot_variants` with one variant carrying
  the `change_prompt` and every slot in `base_series`. The result is every
  device retouched, in a single block with a tab per device.

Calling `iterate_store_screenshot` six times for six screenshots — or
`iterate_store_screenshots` once per device — produces as many blocks, as many
sequential waits and as many half-empty studios: that is the failure this
section exists to prevent.

## Custom product page variants

When building custom product pages from an existing listing, use
`prepare_screenshot_variants` with the complete source series and exactly the
chosen variants. It returns all images as data without opening a studio.
One call takes every variant on every slot; if it ever refuses a batch as too
large, split by variants without removing screenshots. Use `lint_store_text` for promotional text, then call
`preview_custom_product_pages` once with all completed series. The final
comparison is the only panel; the standalone style-picking flow below does
not apply to this workflow.

## The flow: propose, pick, apply

A usable store visual is **designed around the app's real screens**. That is
what separates it from an illustration, and it shapes the whole flow:

**1. Get the screens — open the studio only if you have no other way.** The
studio's drop zone exists for one reason: images the user has and you do not.
If the app is published, its screens are already in the listing (see above) and
opening an empty drop zone only gets in the way. If they are not, call
`open_screenshot_studio` — it renders the studio without generating anything and
costs nothing. Pass what the conversation already established (`app_name`,
`prompt`, `device_preset`) and it arrives pre-filled. Then say, in one sentence:

> Drop your app screens in the studio — the series will be designed around them.

**Never ask for the screens in the conversation.** An image attached to the chat
reaches you as pixels with no URL, and every tool here takes URLs: asking for
them that way produces a dead end where the screens are visibly there and
unusable. If the user attaches them anyway, don't try to work from them and
don't pretend they arrived — open the studio and ask them to drop the same files
in its drop zone, which uploads them and yields the URLs.

**2. Propose three styles.** Once screens are in, `design_store_screenshots`
designs three proposals — Minimalist, Bold, Warm — around **one** real screen.
Nothing is applied yet. Present the three and ask which one to keep. Never pick
for the user: the choice is the point of this step.

Pass **the whole series** in `screens`, hero first, not just the hero. The tool
echoes that list back in its result, and that echo is where step 3 gets its
URLs: the host destroys the app instance at the end of the turn, so the studio
that uploaded the screens is gone by the time the user picks a style. Read the
`screens` of the design result rather than looking for the URLs earlier in the
conversation.

**3. Apply the chosen style.** `apply_screenshot_design` renders every other
screen in that style — take them from the `screens` echoed by the design result,
minus the hero it was designed around. If that echo is missing, say the screens
were lost and ask the user to drop them again in the studio; never invent a URL,
and never fall back to `generate_store_screenshots`, which would silently
produce an illustration instead of their app. Each screen carries a `feature_description` — a short
label like `Home`, `Progress`, `Library` — which becomes its marketing
headline. The chosen proposal leads the returned series, so the order matches
what the user saw when choosing.

The user drives steps 2 and 3 from the studio; its buttons send you the
instruction. Do not call any of these as a first move: the drop zone lives in
the studio, so generating before it exists bills a series produced without the
very screens the user was about to provide.

### When there are no screens at all

`generate_store_screenshots` builds a series from a written scenario alone,
with optional `captions`. Use it only when the user says they have no screens,
or explicitly asks you to go ahead without them — and say plainly that the
result will be illustrative rather than faithful to their interface.

## The device slot

The stores reject anything off-size, so every screenshot is rendered at an exact
slot: one phone and one tablet per store, plus the App Store's iPhone Duo:

| `device_preset` | Store | Portrait |
| --- | --- | --- |
| `iphone_67` | App Store | 1290×2796 |
| `ipad_129` | App Store | 2048×2732 |
| `android_phone` | Play Store | 1080×1920 |
| `android_tablet` | Play Store | 1600×2560 |
| `iphone_duo` | App Store | 2007×2853 (adapted only, see below) |

**Prefer to omit `device_preset`** on `design_store_screenshots` and
`apply_screenshot_design`: the dimensions of the source screen decide, and
pixels beat a guess. Set it only when the user names a target the sources cannot
reveal — asking for iPad visuals from iPhone captures, for instance.

It stays required on `generate_store_screenshots`, which has no source to read,
and on `iterate_store_screenshot`, where it must match the original so the edit
keeps its dimensions.

`iphone_duo` is never generated from scratch: no style, design or generation
tool accepts it. See "iPhone Duo" below.

Ask which store is targeted if it is not obvious, and produce one series per slot
rather than trying to cover both at once. `orientation` defaults to `portrait`;
use `landscape` only for a layout that is genuinely horizontal. The result's
`available_presets` carries the catalogue — read the identifiers there rather
than inventing one.

## Writing the text

Two fields carry the words, and they belong to different steps.

`feature_description`, on each screen of `apply_screenshot_design`, is the one
that matters most: a short label — `Home`, `Progress`, `Library` — which the
service turns into a marketing headline. Keep it to the feature itself, not a
sentence; the service writes the sentence.

`prompt` and `captions`, on `generate_store_screenshots`, only apply to the
no-screens path. `prompt` describes the **series** — the hook, then the
features, then the proof — and `captions` gives one line per screen, in order.
Prefer captions over burying the text in the prompt: what appears on the image
deserves to be explicit and short.

`count` accepts 1 to 6 and defaults to 3. Stores show the first two or three, so
three well-chosen screens beat six repetitive ones.

Headlines are drafted in English at design time; pass `language` (e.g. `fr-FR`)
to `apply_screenshot_design` to have them written in another locale, and to
`iterate_store_screenshot` to preserve the locale already on the image.

## Restituting

The result renders as an interactive studio; hosts that cannot render it receive
the screenshots as images plus their URLs as text. Summarize in a single line —
how many, which slot — then ask which ones to keep.

When the user wants the files, call `download_screenshot_series` with the
series and give them the one zip link it returns — free, and far better than a
list of URLs to save one by one. The studio has a download button for the same
thing.

Never re-display a screenshot as a markdown image (`![…](url)`): the studio and
the tool result already handle it, and hosts don't load remote images into the
conversation. A plain link per screenshot is enough if you want them
downloadable. Never mention the token cost.

Once an iOS series is kept, offer the App Store header (iOS 27) in one
sentence: the visual shown at the top of the product page and in search
results, made from these screenshots with `design_app_store_header` — as the
feature graphic goes with a Play series. For the main product page, pass the
page's kept series in `series` (one entry per device: `device_preset`,
`language`, `screenshots`): the header opens in this studio above them, with a
tab per device. Every action there goes through the chat, so a reopened block
loses nothing: a retouch asks for `iterate_app_store_header`, "Transform to
video" for `animate_app_store_header` (the block polls the video itself, then
asks for `show_app_store_header` — do not poll from the chat), "Upload your
video" sizes the user's own clip, and "Send to the store" asks you to place
it. One image by default; a video only when the user asks. For a custom product page, the header shows with that
page in the pages studio instead (`preview_custom_product_pages`); the
custom-product-pages flow covers it.

## iPhone Duo

App Store Connect has an iPhone Duo slot (the foldable iPhone): 2007×2853 or
1398×2034 portrait and their landscape turns, nothing else. Its series is
adapted from a finished iPhone or iPad series with
`adapt_store_screenshots_to_duo` — same headlines letter for letter, same art
direction and app screens, recomposed for the wider canvas with the device
drawn unfolded. Pass the series in store order with its captions and
`source_device_preset`; when the source is the iPhone series, pass the iPad
series of the same language in `layout_reference`, in the same order, so the
app UI is laid out for the wide screen. Every result is measured; one not at
the exact size is dropped and listed in `failed` rather than returned. The
studio shows it as an "iPhone Duo" tab next to its source (its "+ iPhone Duo"
tab does the same call). Offer it once an iOS series is kept, in one sentence;
it is billed one generation per screenshot. Push it like any slot, with
`device_preset: iphone_duo` (store-publish).

If the tools remain unavailable after connection recovery, report the error
and stop generation. Never fabricate
store screenshots with another image generator: the dimensions would be wrong
and the stores would reject them.

## Refining

Two tools, by scope:

- `iterate_store_screenshots` applies **one change to the whole series** in a
  single call: pass the series in `screenshots`, the change as
  `change_prompt`, and the `device_preset`. Use it for anything that concerns
  every image — a theme, a background, a colour, a season. A screenshot whose
  edit fails keeps its original and its position is listed in `failed`;
- `iterate_store_screenshot` retouches **one** screenshot: pass its
  `image_url` as `screenshot_url`, the requested change as `change_prompt`, and
  **the same `device_preset`** so the output keeps its store dimensions. Pass
  `language` when the screenshot carries text in a locale that must be
  preserved.

Pass the current `series` too — every `image_url` with its caption, in order.
The result then comes back as the whole series with the edit in place, and the
studio shows the set rather than one lone screenshot. The instruction the studio
sends already carries it; keep it intact.

Prefer refining over regenerating whenever the user wants an adjustment: it
keeps the rest of the series consistent.

## Working on every device at once

A published listing usually has several slots — iPhone and iPad at least. Each
step of the work is **one call covering every slot**, never one call per
device: the renders run in parallel, the call lasts about one render whatever
the volume, and the user gets one studio with a tab per device.

- **One change on the whole listing** (a seasonal theme, a new background):
  `build_screenshot_variants` with a single variant and every slot in
  `base_series` (up to 10 screenshots per slot). Not `iterate_store_screenshots`
  once per device.
- **Localizing**: `localize_store_screenshots` with every slot in `slots`
  (`device_preset` + its series) and every locale in `target_languages` — up to
  40, all in the same call. Not one call per device, per locale or per batch of
  screenshots.

The product manager's order is: iterate on the source language until it is
right, then localize, then fix what needs fixing. So never localize in the
same step as an iteration, and never before the user said the source series is
done: every locale is a billed render of every screenshot. Confirm the list of
languages first.

## Localizing

`localize_store_screenshots` re-renders a finished series in other locales, the
design untouched and the text translated. Always localize from the source
series, never from a translation. The result carries the source of every slot
(`sources`) and one series per slot and locale, each with its `device_preset`;
the studio shows a tab per device and a chip per language, and its download
button packs the device on screen, one folder per locale.

Only if that one call refuses the request as too large (slots x locales x
screenshots over its render cap — hundreds of renders), split the locales into
two or three `prepare_localize_screenshots` calls fired together in the same
turn, then call `preview_localized_screenshots` **exactly once** with every
source and every series. Never open a panel per batch, never list intermediate
image URLs, never shorten the language list to fit.

## Requests coming from the studio

The studio lets the user pick the slot, the count, the captions and the
references, then hands the call to you. Its buttons send an instruction that
names a tool and lists its parameters:

> Generate a new batch of store screenshots by calling
> `generate_store_screenshots` with exactly these parameters: …

Call the named tool **once**, with the listed values and nothing else. Don't
rephrase the scenario, don't alter the slot, the count or the captions — the user
chose them in the interface. Don't comment on the result: the studio displays it.

Going through you is what gives every batch its own block in the conversation.
Without it the user would lose their screenshots on reload: the interface is
destroyed at the end of the turn.

That destruction is also why the instruction carries every parameter it needs,
including the full `screens` list. Pass it through unchanged: dropping it is
what leaves step 3 with nothing to render.

See `references/tool-contract.md` for the full parameter contract.

## One headline per screen

`iterate_store_screenshots` takes an optional `captions` list, one entry per
screenshot in order. Use it when every screen must keep its design but say
its own words — a custom product page built around a search intent, a
seasonal series with a different promise per screen. A shared
`change_prompt` alone puts the same sentence on every screen; `captions`
gives each screen its own headline, quoted and asked for verbatim.

## Restaging a series

`iterate_store_screenshots` is not only for headlines: its `change_prompt`
can change the scene around the app's real screen — the instrument, the room,
the season, the person, the props, the background and the accent colour —
while the UI, the brand type and the layout stay. Say what changes and what
stays, in one prompt shared by the whole series, and put the per-screen
headlines in `captions`. That is how one app gets one series per audience.


## A whole batch in one call

When several complete variants are needed at once — one per custom product
page, one per theme, one per audience — call `prepare_screenshot_variants`
rather than `iterate_store_screenshots` in a loop. It takes `base_series`
(the current series of each device slot) and `variants` (label, concept,
captions), applies every variant to every slot and returns them all in one
result, rendered in parallel.

That matters for what the user sees, not only for speed: six separate calls
produce six blocks, each one replacing the panel the previous one opened, so
the user ends up with the last series on screen and nothing to compare. One
call is one block holding the whole set, with the untouched series echoed
beside it.

It is billed per screenshot generated — variants times slots times
screenshots, 40 at most per call — so agree on the concepts with the user
before firing it.
