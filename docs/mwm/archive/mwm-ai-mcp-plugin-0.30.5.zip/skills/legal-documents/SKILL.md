---
name: legal-documents
description: Produce and publish an app's privacy policy and terms of service with the MWM MCP tools get_legal_questionnaire, save_legal_answers, draft_legal_document, publish_legal_document and get_legal_documents. The wording comes from a clause library a lawyer approved; you run the interview and never write the text. Use whenever an app needs a privacy policy URL for App Store Connect or Play Console, when a submission is blocked on that field, when the policy has to be translated, or when what the app collects has changed.
---

# Privacy policy and terms of service

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

Both stores demand a privacy policy URL, and a submission stops without one.
The document is **assembled**, never written: a legal team reviews a library of
clauses; an assembled document still needs to be checked for the app's actual
practices and jurisdictions. Your job is the interview, not the prose.

| Tool | Does |
| --- | --- |
| `get_legal_questionnaire` | the questions that decide what the document says, what the app already answered, what is still missing — free |
| `save_legal_answers` | records answers, merged into what the app already said; publishes nothing |
| `draft_legal_document` | assembles the document as text, with the clauses that came in, those that fell away, and any answer still missing — free |
| `publish_legal_document` | freezes it and serves it at a public URL — outward-facing |
| `get_legal_documents` | every version published and the URLs in force |

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: something a real user will read,
  under their company's name, at a public address.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing.

## You do not write legal text

This is the rule the whole design rests on. The clauses were read and approved
by a lawyer; an app-specific rewrite voids that review, and nobody would ever
notice because the document still reads well.

So:

- Never invent, reword, soften or extend a clause, even when the user asks.
- Never paste a policy the user found elsewhere.
- When a clause reads wrong for this app, say so and stop. Either an answer is
  wrong, which you can fix, or the library needs a new variant, which is the
  legal team's call and not yours.
- When something the app does is covered by no clause at all, say that too. A
  document that stays silent on a real processing activity is the failure this
  whole machine exists to prevent.

## Your first move is always the same

Call `get_legal_questionnaire` before writing a single word to the user. Not
after gathering context, not after a clarifying question: first. It tells you
what has to be asked, what the app already answered, and what is missing. Every
question you would have thought to ask is either in there or does not belong.

Never ask the user for any of this, because it is the wrong question and it
leads somewhere you cannot follow:

- **Their current privacy policy.** You will not reuse it, adapt it, or take
  wording from it. Asking for it invites them to paste text you must refuse,
  and makes the refusal look like a change of mind.
- **A list of their SDKs**, or of their analytics, ad, payment and crash
  providers, as one lump. The questionnaire asks those precisely, one at a
  time, and only the ones that apply. Improvising your own intake produces a
  list that fits no clause.
- **Anything from a code repository.** What the document says comes from the
  answers and the clause library, never from reading source.

If the tools remain unavailable after connection recovery, explain that this
app's legal documents cannot be produced right now. Do not fall back to drafting
a policy yourself: that is the one outcome this skill exists to prevent.

## The interview

**1. Ask what is actually asked.** `get_legal_questionnaire` returns every
question with `asked`. Ask only those: the rest are irrelevant given the
answers so far, and asking an app with no advertising which ad networks it uses
wastes the user's time and makes the interview feel like a form.

**2. Ask in their words, a few at a time.** Group the questions the way the
questionnaire groups them and ask one group per message. Never dump the list.
Use what you already know of the app instead of asking: if the conversation
established the publisher, the app name or the markets, fill those in and say
what you assumed.

**3. Save as you go.** Call `save_legal_answers` after each group rather than
holding everything to the end. It merges, so a later pass only fills gaps, and
`unanswered` tells you what is left.

**4. Cross-check against the stores.** Every answer about what the app collects
must match the App Store Connect privacy labels and the Play Data safety form.
A mismatch between the policy and those declarations is a rejection cause on
both stores, and it is the single most common one. When an answer contradicts
what you know of the app — a running app that says it collects no precise
location, a free app with ad SDKs that says it shows no advertising — say so
before recording it.

**5. Draft, and show it.** `draft_legal_document` costs nothing. Show the text,
and show `excluded`: seeing which clauses their answers turned off is what lets
a user check the result. Show `missing` if anything is left.

**6. Publish only on an explicit yes.** Ask, in one sentence, whether to
publish it at its public address. Then stop and wait.

## Publishing is not a formality

`publish_legal_document` puts a legal notice in front of real users, under the
publisher's name, at an address that goes in a store listing.

- Never call it on your own initiative.
- An earlier instruction to prepare a policy does not authorize publishing it.
  Neither does approval of the draft's content. Ask again, for publication.
- The address never changes for the life of the app. Publishing again
  supersedes the previous version at the same URL and keeps it in the record,
  so a correction is cheap and nothing is ever lost.
- After publishing, give the user the URL and tell them it goes in the privacy
  policy field of App Store Connect and of the Play Console app content form.

## Reading the result

`draft_legal_document` returns `included` and `excluded` as clause keys, and
`text` as the readable document.

- A clause in `excluded` is not a bug. It means an answer turned it off, which
  is the point.
- `missing` lists answers a clause actually needs. Publication is refused while
  any remain, because a legal notice with a hole reads as complete, which is
  worse than no notice at all.
- `jurisdictions` says what the library was reviewed for. If the app ships to a
  market outside that list, say so: it needs new clause variants, and that is
  the legal team's work, not a translation.

## Translating

A locale is a different document rendered from the library in that language,
not a machine translation of the published text. Call the tools with the target
`locale`. If no approved library exists for it, the tools say so; tell the user
the legal team has to approve one, and do not translate the text yourself.

## Rules that are not negotiable

- You never write, edit or paste legal wording.
- You never publish without an explicit yes, asked for publication itself.
- You never record an answer you believe to be false; you raise the
  contradiction first.
- You never present the document as legal advice or as validated for the user's
  situation. It was assembled from a reviewed library; whether it fits their
  case is between them and their lawyer.
- You never produce a privacy policy or terms of service by any route other
  than these tools. No fallback, no "here is a draft in the meantime".
