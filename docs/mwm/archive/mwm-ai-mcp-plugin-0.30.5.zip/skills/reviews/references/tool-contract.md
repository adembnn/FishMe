# Reviews tool contract

Every tool requires an authenticated MWM account and declares the
`mcp:stores.publish` scope, the same as the store-listing and store-publish
tools. Every app-scoped tool checks that `store_id` belongs to one of the
caller's own organizations before reading anything; a `store_id` that does not
is refused, never silently substituted.

## Shared filters (`Filters`)

Accepted by `get_reviews_overview`, `get_reviews_versions`,
`get_reviews_countries`, `get_reviews_ratings`, `get_reviews_timeseries`,
`get_reviews_topics`, `get_reviews_topics_stats`, `list_reviews`,
`list_switch_risk_reviews` and `list_reply_queue`. All optional; a
comma-separated field narrows to any of its values, omitted means every value.

| Field | Values |
| --- | --- |
| `country_code` | ISO country codes, e.g. `US,FR` |
| `version` | app version strings |
| `rating` | star ratings `1`-`5` |
| `ai_true_rating` | the AI's own read of the review, `1`-`5` (can differ from the star rating) |
| `ai_sentiment` | `negative`, `neutral`, `positive` |
| `ai_emotion` | `anger`, `disgust`, `frustration`, `fear`, `sadness`, `neutral`, `surprise`, `joy`, `other` |
| `has_developer_reply` | `true` or `false` |
| `first_date_from` / `first_date_to` | `YYYY-MM-DD`, inclusive. Default: last 90 complete days ending yesterday |
| `ai_score` | `price`, `support`, `quality`, `update` — keeps reviews carrying at least one AI dimension score |
| `ai_topic` | `access_connectivity`, `bug`, `marketing`, `monetization`, `product_feedback`, `report_a_concern`, `sentiment`, `strategic` |
| `ai_topic_label` | finer-grained topic labels, e.g. `crash`, `ads_volume_frequency`; paired strictly with `ai_topic` when both are set |
| `user_type` | `whale`, `established`, `churn`, `detracting`, `promoting` |
| `keyword` | free-text phrase search over reviewer name, title, body and their English translations |

`get_reviews_topics` accepts the set but ignores `ai_topic`/`ai_topic_label`.
`get_reviews_portfolio` only accepts `first_date_from`, `first_date_to`,
`ai_true_rating`, `ai_sentiment`, `ai_emotion`, `has_developer_reply` — no
`store_id`, no country/version/rating/topic/keyword.

## `get_reviews_overview`

`store_id` (required) + `Filters` + `compare` (`previous_period` to also
return `previous_metrics`).

Returns `metrics` — `nb_reviews`, `avg_rating`, `avg_true_sentiment`, `nps`,
`ratio_5_to_1_star`, `perc_good_reviews`, `sentiment_index`, reply coverage
(`ratio_replied`, `nb_pending_reply`, `nb_no_reply`, `avg_time_to_response`),
salvage (`avg_salvage_delta`, `salvage_rate`), the four AI dimension scores
(`avg_price_score`, `avg_support_score`, `avg_quality_score`,
`avg_update_score`), stability (`ratio_stability_negative_perception`) and
user-status counts (`nb_whale_user`, `nb_established_user`, …) — plus
`previous_metrics` when `compare` was set. Every rate/average is `null` when
its denominator is empty, never `0`.

## `get_reviews_portfolio`

No `store_id`. Returns `window`/`previous_window`, a pooled `summary` (
`nb_apps`, `nb_active_apps` — at least 30 reviews in the window —,
`nb_reviews`, `avg_rating`, `rating_delta_vs_previous`, `avg_true_sentiment`,
`nps`, `nb_needs_reply`), and `apps[]` — one row per iOS app of the caller's
organizations, in no particular order, each with `store_id`, the same KPI
subset, `rating_delta_vs_previous` and a zero-filled ISO-weekly
`weekly_review_sparkline`. Empty when the caller has no iOS app with a
configured store ID.

## `get_reviews_versions` / `get_reviews_countries` / `get_reviews_ratings`

`store_id` (required) + `Filters` (+ `limit` on versions and countries — max
250 on countries). Each returns a list (`versions[]`, `countries[]`,
`ratings[]`) of `{ key or version/country_code/rating, metrics }`, `metrics`
being the same object as `get_reviews_overview`. Versions and countries are
ranked by review count; versions is newest-first when unranked.

## `get_reviews_timeseries`

`store_id` (required) + `Filters` + `granularity` (`day`, `week` default,
`month`) + `fill` (`none` default: skip empty buckets; `zero`: return every
bucket of the window). Returns `points[]` — `{ period_start, metrics }`,
`metrics` extending the overview object with `nb_reviews_1_star` …
`nb_reviews_5_star`.

## `get_reviews_topics`

`store_id` (required) + `Filters` (minus the topic fields). Returns
`topics[]` — `{ category, nb_reviews, labels: [{ label, nb_reviews }] }`.

## `get_reviews_topics_stats`

`store_id` (required) + `Filters` + `group_by` (`category` default, `label`)
+ `compare` (`previous_period` or `previous_version` — the latter needs
`rating` set to exactly one version) + `limit` (default 20, max 50). Returns
`group_by`, `nb_reviews_total`, and `topics[]` ranked by share — each `{ key,
category?, share, metrics, tone, previous_metrics?, previous_share?,
previous_tone?, delta_avg_true_rating? }` when `compare` was set. `tone` is
the topic's qualitative read (fix-first / watch / healthy / amplify-worthy, as
a string).

## `list_reviews`

`store_id` (required) + `Filters` + `sort` (`recent` default, `oldest`) +
`cursor` + `limit` (default 100, max 200). Returns `reviews[]`, `limit`,
`next_cursor` (absent on the last page). Each review carries `review_id`,
`country_code`, `version`, `first_date`, `rating`, `ai_true_rating`,
`nickname`, `title`/`content` (original) and their English translations,
`ai_original_language`, `ai_sentiment`, `ai_emotion`, `ai_topics[]` (`{
category, label }`), the four AI dimension scores (`null` = not processed,
`-1` = processed but not applicable, `>=0` = actual 0-10 score),
`is_whale_user`/`is_established_user` badges, the switch-risk flags
(`is_churn_user`, `is_detracting_user`, `has_competitor_mention_bad_sentiment`,
`is_marketing_mismatch`, `is_bait_switch`), `is_at_risk`, `save_score`,
`ai_ai_reply` (+ its English translation) — an AI-drafted reply seed, never
posted without the user reading it —, `has_developer_reply`,
`has_pending_developer_reply`, and the existing developer response fields
when there is one.

## `list_switch_risk_reviews`

`store_id` (required) + `Filters` + `flag` (`competitor_mention_bad_sentiment`
| `marketing_mismatch` | `bait_switch` | `churn_user` | `detracting_user`;
omit for the union of all five) + `sort` (`save_score` default — most
salvageable first —, `recent`, `oldest`) + `cursor` + `limit`. Returns
`reviews[]` (same shape as `list_reviews`), `counters` (per-flag counts),
`limit`, `next_cursor`.

## `list_reply_queue`

`store_id` (required) + `Filters` + `severity` (**required**: `critical`,
`medium`, `low`, `core_user`) + `show` (`unanswered` default, `pending`) +
`cursor` + `limit`. Returns `reviews[]`, `debt` (`nb_reviews`,
`nb_unreplied`, `nb_replied`, `nb_pending_reply`, `ratio_replied`,
`median_time_to_response`, `nb_critical_open`, `nb_medium_open`,
`nb_low_open`, `nb_core_open`), `limit`, `next_cursor`.

## `reply_to_review`

`store_id`, `review_id`, `response_body` (all required). The server injects
`done_by` from the caller's own MWM account — never pass or ask for one.

Returns `status`, `store_id`, `review_id`, `developer_response_id`, and
`warnings[]` when part of the pipeline's own bookkeeping (not the reply
itself) could not be confirmed. **Destructive, not idempotent, no automatic
retry** — see the skill's "Replying to a review" section before calling it.
