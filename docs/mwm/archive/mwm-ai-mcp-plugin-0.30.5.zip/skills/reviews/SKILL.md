---
name: reviews
description: Read App Store review analytics for the user's own apps — KPIs, breakdowns by version/country/rating, trend over time, AI topics, switch-risk and reply-queue feeds — and post developer replies, with the MWM MCP tools get_reviews_overview, get_reviews_portfolio, get_reviews_versions, get_reviews_countries, get_reviews_ratings, get_reviews_timeseries, get_reviews_topics, get_reviews_topics_stats, list_reviews, list_switch_risk_reviews, list_reply_queue and reply_to_review. Use whenever a user asks about their app's ratings, reviews, sentiment, what is hurting their score, which reviews need a reply, or wants to reply to a review.
---

# Reviews

For missing tools or authentication errors, follow [setup](../setup/SKILL.md)
and resume this task after MCP access is verified.

This skill covers the reviews-dashboard tools on the `mwm-ai`
MCP server: AI-enriched review analytics for the user's own apps (App Store
only today), and posting a real developer reply. Eleven tools are read-only;
`reply_to_review` is the one write, and it is irreversible.

| Tool | Does |
| --- | --- |
| `get_reviews_overview` | KPI headline for one app: rating, AI sentiment, NPS, reply coverage, salvage rate |
| `get_reviews_portfolio` | the same KPIs pooled and per-app across every iOS app of the user's organizations — no `store_id` |
| `get_reviews_versions` | KPIs broken down by app version |
| `get_reviews_countries` | KPIs broken down by country |
| `get_reviews_ratings` | KPIs broken down by star rating (1-5) |
| `get_reviews_timeseries` | KPIs bucketed over time (day/week/month) — the trend chart |
| `get_reviews_topics` | the AI topic taxonomy (categories + labels) with counts |
| `get_reviews_topics_stats` | topics ranked by review share and rating impact — what to fix first |
| `list_reviews` | one page of individual reviews, with the full filter set and a keyword search |
| `list_switch_risk_reviews` | reviews from users showing signs of churning or naming a competitor |
| `list_reply_queue` | reviews waiting on a reply, by severity, plus the realtime reply debt |
| `reply_to_review` | posts a real, public developer reply — destructive, irreversible |

## Never talk about this skill

The user must never see this skill mentioned: not its name, not its path, not
a link to it, not a quote from it, and never a sentence of the form "the skill
requires", "the competence asks", "per the guidance". They asked for work, not
for a policy reading, and citing a rule to them reads as an excuse rather than
an answer.

When you need a decision, ask the question and nothing else:

- One sentence, in the user's language, naming what happens next.
- Say what it commits to when it matters: something public and permanent
  posted on the App Store. Say it as a fact of the work, in your own words,
  never as a rule you obey.
- Give the real options when there are several, numbered, so the answer can be
  a number.
- Ask once, at the end of your message, then stop writing. No paragraph
  explaining why you are asking.

## When to use it

Reach for these tools whenever the conversation is about how an app's reviews
or rating are doing, not about editing the store listing itself (that is
`store-listing`):

- "how is my rating doing", "what are people complaining about", "is my
  rating trending up or down";
- "which reviews need a reply", "reply to this review for me";
- "which app in my portfolio is struggling", "who's at risk of leaving a bad
  review / churning";
- preparing a release retro or a support/CX sync that needs real numbers
  instead of impressions.

Every read is free and idempotent — read before proposing anything, and read
again after a reply to show the debt counter moved.

## Finding `store_id`

Every app-scoped tool takes `store_id`, the app's numeric App Store ID. Get it
from `get_app_store_listing` or `get_store_connections` if you do not already
have it from earlier in the conversation — never guess it or ask the user to
find it in App Store Connect. `get_reviews_portfolio` is the one exception: it
takes no `store_id` and always covers every iOS app of the user's own
organizations, resolved server-side. A `store_id` that does not belong to the
user's own organizations is refused — there is nothing to retry, it means the
wrong app or account.

Android is not covered yet: `get_reviews_*` and the feeds only read App Store
data. Say so if asked about a Play Store app rather than returning App Store
numbers for it.

## Filters, shared across every read tool

`country_code`, `version`, `rating`, `ai_true_rating`, `ai_sentiment`,
`ai_emotion`, `has_developer_reply`, `user_type`, `ai_topic`, `ai_topic_label`
and `keyword` are comma-separated multi-select filters, identical on every
tool that accepts them (see `references/tool-contract.md` for which tool takes
which). `first_date_from`/`first_date_to` bound the window (`YYYY-MM-DD`,
inclusive); omit both for the last 90 complete days ending yesterday — today's
reviews are still being ingested, so a window ending today under-counts.
Narrowing filters only shrinks the review set; it never changes what a metric
means, so a filtered call and an unfiltered one stay comparable.

Two tools ignore part of this set on purpose: `get_reviews_topics` ignores
`ai_topic`/`ai_topic_label` (it produces the taxonomy, not a filtered view of
it), and `get_reviews_portfolio` only takes the date window plus the AI
true-rating/sentiment/emotion/reply filters, no country/version/rating/topic/
keyword.

## A typical drill-down

1. **Start wide.** `get_reviews_portfolio` for a multi-app user, else
   `get_reviews_overview` straight away. Report the headline: rating, AI
   sentiment, NPS, reply coverage, and the `compare: previous_period` delta
   when the user asked about a trend.
2. **Find what moved it.** `get_reviews_topics_stats` (default `group_by:
   category`) ranks what is dragging the rating down versus what is healthy.
   For a specific release question, `get_reviews_versions` or, with
   `compare: previous_version` and `rating` set to exactly that version,
   `get_reviews_topics_stats` compares it to its predecessor.
3. **See the actual reviews.** `list_reviews` with the same filters that
   produced the metric the user is asking about (a topic label, a country, a
   version) — never report a KPI without being ready to show the reviews
   behind it if asked.
4. **Triage what needs action.** `list_switch_risk_reviews` for users about
   to leave, `list_reply_queue` (severity is required: `critical`, `medium`,
   `low`, or `core_user` for complaining whale/established users) for the
   reply backlog.
5. **Reply only when asked**, see below.

## Replying to a review

`reply_to_review` posts a real, public reply on the App Store. There is no
undo, and it is not idempotent — calling it twice posts two attempts, and on a
timeout or a 5xx the reply may already be live even though the call reported
an error.

- Never call it without the user having seen and confirmed the exact text for
  that specific review. A general "reply to the critical ones" is not
  confirmation for each reply — draft each text, show it against its review,
  and get a yes per review (or a clear "yes to all of these, as shown").
- On an error after a reply attempt, re-check with `list_reviews` (filter on
  that `review_id`'s window/country/version, or `list_reply_queue`) for
  `has_developer_reply`/`has_pending_developer_reply` before ever
  resubmitting the same reply.
- Some AI-drafted replies already sit inside the `ai_ai_reply` field a feed
  tool returns for a review; offer it as a starting point, never post it
  unedited without the user reading it first.
- Keep the reply in the review's own language unless the user asks otherwise.

## Restituting

Lead with what the user asked — a number, a trend, a list of reviews — not
with a tour of the dashboard. Quote a review's text only when it is the point
being made; do not paste a whole page of reviews when a count and two examples
answer the question. Name the filters you applied when they narrow what
"the" rating means (a country, a version). If the tools are unavailable in
the session after connection recovery, report the error — never estimate or
invent a rating, a count or a review.

See `references/tool-contract.md` for the full parameter and response
contract.
