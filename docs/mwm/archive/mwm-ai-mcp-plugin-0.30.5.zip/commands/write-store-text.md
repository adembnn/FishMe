---
description: Write App Store and Google Play listing text and review it against the stores' rules (get_store_text_rules, review_store_text).
argument-hint: [app name + what it does + target stores and locales]
---

User request: $ARGUMENTS

Write store listing text with the `mwm-ai` MCP server.

1. Call `get_store_text_rules` for the stores and locales targeted. Never work
   from remembered limits, and never guess a locale code.
2. If the app's positioning is missing or too vague, ask **one** short question,
   then continue.
3. Gather evidence: `search_market_apps` for the competitor set, then
   `analyze_market_keywords` with the store ids it returned, for the country
   and device targeted. Popularity and difficulty come from there and nowhere
   else.
4. Write one sheet per (store, locale), with two or three variants on the
   fields where the wording choice is real. Always write Play release notes.
5. Call `review_store_text` **once**, with every sheet in the same call, and
   pass the competitor rows and keyword metrics you actually used.
6. Summarize in one line and stop: the review interface displays the copy. Fix
   store-enforced blockers and call again; leave practitioner habits to the
   human. If the tools are unavailable, say so and stop.
