---
description: Generate App Store or Play Store screenshots through the MWM MCP server (generate_store_screenshots).
argument-hint: [app name + what the series should show, and the target store]
---

User request: $ARGUMENTS

Generate store screenshots with the `generate_store_screenshots` tool of the
`mwm-ai` MCP server.

1. Call `open_screenshot_studio` first — it costs nothing and renders the studio
   pre-filled. Ask the user to drop their real app screens: the series is designed
   around them. URLs they give you can be used directly. Never encode an image
   yourself.
2. Once screens are in, call `design_store_screenshots` with one of them as
   `hero_screenshot_url` to get three style proposals — Minimalist, Bold, Warm.
   Present them and ask which to keep; never choose for the user.
3. Call `apply_screenshot_design` with the chosen proposal and the remaining
   screens, each with a short `feature_description` (`Home`, `Progress`…) that
   becomes its headline.
4. Prefer omitting `device_preset`: the source screens' dimensions decide.
5. Let the studio display everything: summarize in one line and neither restate
   the list nor re-embed the images. If the tools are unavailable, say so and stop
   rather than using another image generator.
