---
description: Generate app icon proposals through the MWM MCP server (generate_app_icons).
argument-hint: [app description + optional creative direction]
---

User request: $ARGUMENTS

Generate icon proposals with the `generate_app_icons` MCP tool of the
`mwm-ai` server.

1. If the app description is missing or too vague, ask **one** short question to
   get it, then continue.
2. Infer from the arguments what has been supplied: creative direction
   (`user_prompt`), brand palette (`brand_colors`, as hex values), visual style
   (`style_id`), number of proposals (`count`, 1 to 6, defaults to 4), quality
   level (`quality`).
3. Call `generate_app_icons` exactly once with those parameters.
4. Let the interactive grid display the proposals: summarize in one line (how
   many, which style) and copy out neither the list nor the images — a markdown
   image does not render in the conversation. If the tool is unavailable, say so
   and stop rather than falling back to another image generator.
