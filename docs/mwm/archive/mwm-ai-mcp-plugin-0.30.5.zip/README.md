# MWM AI plugin

Distribution package for the hosted MWM MCP server. It ships no executable and
no credential: `.mcp.json` points at the Cloud Run deployment, so there is no
local prerequisite (no Go, no gcloud).

## Contents

| Path | Role |
| --- | --- |
| `.claude-plugin/plugin.json` | manifest read by Claude Code and claude.ai |
| `.codex-plugin/plugin.json` | manifest read by Codex — byte-identical to the one above |
| `.mcp.json` | desktop MCP transport, timeout and OAuth declaration |
| `mcp.json` | source for the portable OpenAI submission ZIP; omitted from the desktop ZIP |
| `skills/setup/` | connect an MWM account, recover missing tools and verify MCP access |
| `skills/app-icons/` | when and how to use the icon tools |
| `skills/store-screenshots/` | when and how to use store screenshot tools |
| `skills/market-intelligence/` | how to research mobile markets, competitors, and keyword opportunities |
| `skills/store-listing/` | how to read a store listing (public page or connected account) and iterate on it |
| `skills/store-connection/` | how to check store connections and guide setup in MWM Console |
| `skills/store-publish/` | how to push texts, screenshots and graphics to the connected listings, with confirmation, and submit an App Store version for App Review |
| `skills/app-store-events/` | how to design, create and submit App Store in-app events, from the idea to App Review |
| `skills/custom-product-pages/` | how to audit keywords, propose pages by search intent and build App Store custom product pages |
| `skills/play-custom-listings/` | how to design Google Play custom store listings per audience, keyword or campaign (drafts: Play has no API for them) |
| `skills/play-promotional-content/` | how to design Google Play promotional content — offers, events, major updates (drafts: Play has no API for them) |
| `skills/store-text/` | how to write listing copy and check it against the stores' real limits |
| `skills/store-release/` | how to read where a version stands and send an Android build to a Play track |
| `skills/legal-documents/` | how to run the legal interview and publish a privacy policy or terms of service |
| `skills/landing-page/` | how to build an app's landing page from its store listing and publish it at a stable address |
| `skills/reviews/` | how to read App Store review analytics for your apps and reply to reviews |
| `commands/generate-app-icons.md` | the `/generate-app-icons` slash command |
| `assets/` | plugin listing icon |

Only one of the two manifests is strictly necessary: every Codex runtime loader
resolves the chain `.codex-plugin/plugin.json` → `.claude-plugin/plugin.json` →
`.cursor-plugin/plugin.json`, and Claude Code loads a plugin installed from a
marketplace even with no manifest at all (it falls back to auto-discovery plus
the marketplace entry). We keep both so each host reads its native manifest
instead of a legacy fallback. OpenAI also supports this compatibility format
for package uploads.
The two files are byte-identical: `cp` one over the other on release.

The Codex manifest references `.mcp.json` so desktop clients keep the remote
transport's 900-second tool timeout. `mcp.json` uses the OpenAI submission
format to declare OAuth explicitly. The submission ZIP includes a generated
root `plugin.json` with `extensions.com.openai.interface`, onboarding and
review metadata; it omits the desktop compatibility files. Keep the URL and
auth settings of both formats in sync.
Test MCP discovery on supported desktop versions before changing these entry
points to a portable root manifest.

## Authentication

Importing the ZIP installs the skills and MCP declaration. Connecting the
user's MWM account is a separate OAuth step; the host may require an explicit
**Authenticate** action instead of opening login during import. Signing in to
MWM Console alone does not authorize Codex.

After installation, run the plugin's setup workflow or ask "Help me connect
MWM AI". In Codex desktop, open Settings → MCP servers, select
**Authenticate** for MWM AI, complete sign-in and consent in the browser,
then return to Codex. Restart the MCP server or start a new chat if its tools
have not refreshed. The [setup skill](skills/setup/SKILL.md) includes recovery
when the plugin's server is absent and verifies access with a free read.

OAuth uses public Dynamic Client Registration (DCR). The host discovers the
Account server via `WWW-Authenticate` → `.well-known/oauth-protected-resource`
→ `.well-known/oauth-authorization-server`. Both MCP files declare OAuth and
the four broad capability scopes: `mcp:icons.generate`,
`mcp:market-intelligence.read`, `mcp:screenshots.generate`,
`mcp:stores.publish`, plus `offline_access` for refresh access.

Each token is per-user and is never distributed inside the plugin.
Store account setup is handled separately by `store-connection` after MCP
access works.

The repo marketplace's `ON_INSTALL` authentication policy is not part of the
ZIP. The package's onboarding skill supplies a setup entry point; it does not
force every host to start OAuth automatically. See OpenAI's
[onboarding guide](https://developers.openai.com/plugins/build/plugins#add-an-onboarding-skill),
[MCP authentication fields](https://developers.openai.com/plugins/build/plugins#configure-mcp-authentication)
and [desktop connection controls](https://learn.chatgpt.com/docs/extend/mcp#configure-in-the-chatgpt-desktop-app).

## Environment

Both MCP declarations target **production**:

```
https://mcp.mwm.ai/mcp
```

The URL must match the OAuth token audience exactly — see
`OAuthServer.MCPResourceURL` in `mwm-publishing-platform/internal/config.go`.
A mismatch breaks authentication.

## Tools

- `generate_app_icons` — 1 to 6 proposals from a product brief;
- `iterate_app_icon` — refines an existing proposal without regenerating it;
- `open_screenshot_studio`, `generate_store_screenshots`,
  `iterate_store_screenshot` and `build_screenshot_variants` — create and
  refine store listing visuals, one series or a whole batch of variants;
- `search_market_apps` — finds semantically related apps and ranks the candidate
  set with typed market filters and metrics;
- `analyze_market_keywords` — finds demand, difficulty, visibility, traffic,
  and per-app rankings across a dynamic app market;
- `get_market_chart_history` — reads complete-day iPhone, iPad and Google Play chart positions and rank movement;
- `get_market_reviews_insights` — compares public review themes across selected competitors;
- `get_market_competitor_ads` — reads observed Meta ad creatives and media links;
- `show_market_media` — displays selected MWM-hosted images and videos in one gallery;
- `get_store_connections` — says whether App Store Connect and Google Play are
  connected and returns external MWM Console setup links; credentials are configured only in MWM Console;
- `get_public_store_listing` — reads the public store page of any app, with
  every screenshot's URL, dimensions and device slot;
- `get_app_store_listing`, `get_play_store_listing` — read the user's own
  editable listing through the connected accounts;
- `get_store_listing_status` — says what a listing still lacks, locale by locale;
- `update_app_store_listing_texts`, `update_app_store_screenshots`,
  `update_play_store_listing`, `update_play_store_screenshots`,
  `update_play_store_graphics` — push texts, screenshot slots, icon and feature
  graphic to the connected listings (destructive; nothing is submitted for
  review);
- `get_store_listing`, `edit_store_listing`, `edit_store_screenshots`,
  `plan_store_send`, `send_store_listing`, `get_store_send`,
  `get_store_listing_activity`, `create_store_version`, `add_store_language`,
  `get_store_submission`, `submit_store_version_for_review`,
  `manage_store_release`, `get_assistant_settings`, `set_assistant_setting` —
  where the server offers them, the App Store listing MWM keeps for every
  editor: drafts, sends to App Store Connect as the user's assistant settings
  allow, the next version and its languages, then submission to App Review and
  the release that follows, on explicit request;
- `get_app_store_event_rules`, `list_app_store_events`, `get_app_store_event`,
  `design_app_store_event`, `iterate_app_store_event`,
  `create_app_store_event`, `update_app_store_event`,
  `delete_app_store_event`, `submit_app_store_event` — App Store in-app
  events: the rules, the app's events, AI-designed card, details page and
  texts reviewed in the in-app event studio, creation with media upload,
  updates, and submission to App Review on explicit request;
- `get_custom_page_opportunities`, `preview_custom_product_pages`, `list_custom_product_pages`,
  `get_custom_product_page`, `create_custom_product_page`,
  `update_custom_product_page`, `delete_custom_product_page`,
  `submit_custom_product_page` — App Store custom product pages: the keyword
  field scored with market intelligence, pages with screenshot slots and
  keyword targeting, submission on explicit request.
- `get_play_promotion_rules`, `generate_play_feature_graphic`,
  `design_play_custom_listing`, `prepare_play_custom_listings`,
  `preview_play_custom_listings`, `design_play_promotional_content`, `iterate_play_promotional_content` —
  Google Play custom store listings and promotional content: Google's rules,
  the 1024x500 feature graphic, every custom listing's banner and Android
  screenshots rendered in one background call, the 1920x1080 promotional image without text,
  drafts checked against Google's limits and schedule, and the Google Play
  studio where the user edits them and copies each field. Google has no Play
  API for either, so nothing is written to Play Console.

Creative tools render as interactive MCP Apps on hosts that support them and
fall back to images plus text URLs elsewhere. The market intelligence tools
return structured results intended for further agent reasoning. The interactive UIs
require a Cloud Run deployment that includes their bundled frontend assets.

## Releasing a change

Hosts compare **versions**, not contents: without a `version` bump in both
`plugin.json` files, an edited skill never reaches users, even after a
marketplace refresh.

Build from the repository root with `python3 scripts/build-plugin-zip.py`.
Distribute the generated `dist/mwm-ai-plugin-<version>.zip`. This preserves
hidden manifests and omits Finder metadata, previous ZIPs and review files.

For the public review portal, run the same command with `--format submission`
and upload `dist/mwm-ai-plugin-submission-<version>.zip`. Its root manifest
and MCP configuration use the portable format documented by OpenAI. This
does not establish an OAuth connection or perform any review submission.

## Support

Contact [support@mwm.ai](mailto:support@mwm.ai).

Terms of service: [mwm.ai/terms-of-service](https://mwm.ai/terms-of-service).
